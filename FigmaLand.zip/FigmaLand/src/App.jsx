
import { Suspense, useState } from "react"
import {
  Box,
  ChakraProvider,
  Spinner,
  Container,
  Heading,
  Text,
  Button,
  Image,
  VStack,
  HStack,
  Avatar,
  Modal,
  ModalOverlay,
  ModalContent,
  ModalHeader,
  ModalBody,
  ModalCloseButton,
  useDisclosure,
  SimpleGrid,
} from "@chakra-ui/react"
import { motion, AnimatePresence } from "framer-motion"
import Header from "./components/header/Header"
import Hero from "./components/hero/Hero"
import Features from "./components/features/Features"
import Partners from "./components/partners/Partners"
import Footer from "./components/footer/Footer"
import Pricing from "./components/pricing/Pricing"
import Contact from "./components/contact/Contact"

const MotionBox = motion(Box)
const MotionHeading = motion(Heading)
const MotionText = motion(Text)
const MotionImage = motion(Image)

// Testimonial data
const testimonials = [
  {
    id: 1,
    company: "IBM",
    logo: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/logos_ibm-jPYf5iPJql6QkOMO7nOUeRYDH0SrkU.png",
    quote:
      "Most calendars are designed for teams. Slate is designed for freelancers who want a simple way to plan their schedule.",
    author: {
      name: "Organize across",
      title: "UI designer",
      avatar: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Ellipse%202-4NydoQy9CXvDVYcahnUP7symwr3ISm.png",
    },
  },
  {
    id: 2,
    company: "Microsoft",
    logo: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/%40%20partner-style-2%20%282%29-5QJm2dQmREEbXExQnYRIMD6v7DCK7L.png",
    quote:
      "Slate helps you see how many more days you need to work to reach your financial goal for the month and year.",
    author: {
      name: "Sarah Anderson",
      title: "Product Manager",
      avatar: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/images-DLlyhJ8pFpEJ3Zyq8PrygDfLrgdhEn.jpeg",
    },
  },
  {
    id: 3,
    company: "Google",
    logo: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/%40%20partner-style-2-B1VzruR7xIowdiLWmkQOOC4nGBaoTK.png",
    quote:
      "The interface is clean and intuitive. Perfect for freelancers who need a straightforward scheduling solution.",
    author: {
      name: "Michael Brown",
      title: "Senior Developer",
      avatar:
        "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/images%20%281%29-p0OIeeLN3PpZcbO5ufOOaibGtOi3Ai.jpeg",
    },
  },
]

// TestimonialCard component
const TestimonialCard = ({ testimonial, isExpanded = false }) => {
  return (
    <MotionBox
      bg="white"
      p={8}
      borderRadius="xl"
      boxShadow="lg"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      whileHover={{ y: -5, boxShadow: "2xl" }}
    >
      <VStack spacing={6} align="center">
        <MotionImage
          src={testimonial.logo}
          alt={testimonial.company}
          height="40px"
          objectFit="contain"
          whileHover={{ scale: 1.05 }}
        />
        <MotionText fontSize={isExpanded ? "lg" : "md"} color="gray.600" textAlign="center" lineHeight="tall">
          {testimonial.quote}
        </MotionText>
        <HStack spacing={4} align="center">
          <Avatar src={testimonial.author.avatar} size="md" name={testimonial.author.name} />
          <Box textAlign="left">
            <Text fontWeight="medium" color="gray.800">
              {testimonial.author.name}
            </Text>
            <Text fontSize="sm" color="gray.500">
              {testimonial.author.title}
            </Text>
          </Box>
        </HStack>
      </VStack>
    </MotionBox>
  )
}

// Testimonial component
const Testimonial = () => {
  const { isOpen, onOpen, onClose } = useDisclosure()
  const [hoveredIndex, setHoveredIndex] = useState(null)

  return (
    <Box as="section" py={20} bg="gray.50" id="testimonial-section">
      <Container maxW="container.xl">
        <VStack spacing={12}>
          <MotionHeading
            as="h2"
            fontSize={{ base: "3xl", md: "4xl" }}
            textAlign="center"
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            Testimonials
          </MotionHeading>

          {/* Main Testimonial */}
          <AnimatePresence>
            <TestimonialCard testimonial={testimonials[0]} />
          </AnimatePresence>

          {/* More Testimonials Button */}
          <MotionBox initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.5 }}>
            <Button
              colorScheme="blue"
              size="lg"
              onClick={onOpen}
              _hover={{
                transform: "translateY(-2px)",
                boxShadow: "lg",
              }}
            >
              More Testimonials
            </Button>
          </MotionBox>

          {/* Testimonials Modal */}
          <Modal isOpen={isOpen} onClose={onClose} size="6xl">
            <ModalOverlay backdropFilter="blur(4px)" />
            <ModalContent>
              <ModalHeader>More Success Stories</ModalHeader>
              <ModalCloseButton />
              <ModalBody pb={8}>
                <SimpleGrid columns={{ base: 1, md: 2, lg: 3 }} spacing={8}>
                  {testimonials.map((testimonial, index) => (
                    <MotionBox
                      key={testimonial.id}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: index * 0.1 }}
                      onHoverStart={() => setHoveredIndex(index)}
                      onHoverEnd={() => setHoveredIndex(null)}
                      whileHover={{ scale: 1.02 }}
                    >
                      <TestimonialCard testimonial={testimonial} isExpanded={true} />
                    </MotionBox>
                  ))}
                </SimpleGrid>
              </ModalBody>
            </ModalContent>
          </Modal>
        </VStack>
      </Container>

      {/* Background Elements */}
      <Box position="absolute" top="20%" left="5%" zIndex={0}>
        <MotionBox
          width="300px"
          height="300px"
          borderRadius="full"
          bg="blue.400"
          filter="blur(80px)"
          opacity="0.1"
          animate={{
            scale: [1, 1.2, 1],
            opacity: [0.1, 0.15, 0.1],
          }}
          transition={{
            duration: 8,
            repeat: Number.POSITIVE_INFINITY,
            ease: "easeInOut",
          }}
        />
      </Box>
      <Box position="absolute" bottom="10%" right="5%" zIndex={0}>
        <MotionBox
          width="250px"
          height="250px"
          borderRadius="full"
          bg="purple.400"
          filter="blur(80px)"
          opacity="0.1"
          animate={{
            scale: [1, 1.3, 1],
            opacity: [0.1, 0.2, 0.1],
          }}
          transition={{
            duration: 6,
            repeat: Number.POSITIVE_INFINITY,
            ease: "easeInOut",
            delay: 1,
          }}
        />
      </Box>
    </Box>
  )
}

// Main App component
function App() {
  return (
    <ChakraProvider>
      <MotionBox initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} transition={{ duration: 0.5 }}>
        <Header />
        <main>
          <Suspense fallback={<LoadingSpinner />}>
            <Hero />
          </Suspense>
          <Suspense fallback={<LoadingSpinner />}>
            <Box id="features-section">
              <Features />
            </Box>
          </Suspense>
          <Suspense fallback={<LoadingSpinner />}>
            <Box id="partners-section">
              <Partners />
            </Box>
          </Suspense>
          <Suspense fallback={<LoadingSpinner />}>
            <Testimonial />
          </Suspense>
          <Suspense fallback={<LoadingSpinner />}>
            <Box id="pricing-section">
              <Pricing />
            </Box>
          </Suspense>
          <Suspense fallback={<LoadingSpinner />}>
            <Box id="contact-section">
              <Contact />
            </Box>
          </Suspense>
        </main>
        <Suspense fallback={<LoadingSpinner />}>
          <Footer />
        </Suspense>
      </MotionBox>
    </ChakraProvider>
  )
}

const LoadingSpinner = () => (
  <Container centerContent py={20}>
    <Spinner size="xl" color="blue.500" thickness="4px" />
  </Container>
)

export default App

