
import { useState, useRef } from "react"
import {
  Box, Container, Heading, Text, Button, Image, SimpleGrid, VStack, Modal, ModalOverlay,
  ModalContent, ModalHeader, ModalBody, ModalCloseButton, useDisclosure, Link, HStack,
} from "@chakra-ui/react"
import { motion, AnimatePresence } from "framer-motion"
import { ExternalLink, ArrowRight, Globe, Users, Award } from "lucide-react"

const MotionBox = motion(Box)
const MotionImage = motion(Image)
const MotionHeading = motion(Heading)
const MotionText = motion(Text)

const partners = [
  {
    name: "Google",
    logo: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/%40%20partner-style-2-B1VzruR7xIowdiLWmkQOOC4nGBaoTK.png",
    website: "https://google.com",
    description: "The world's leading search engine and technology company.",
    employees: "156,500+",
    founded: "1998",
    headquarters: "Mountain View, California",
  },
  {
    name: "Amazon",
    logo: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/%40%20partner-style-2%20%281%29-F49nPLACsGMSNDO6zQYbLvaxMYIdLI.png",
    website: "https://amazon.com",
    description: "Global leader in e-commerce and cloud computing services.",
    employees: "1.6M+",
    founded: "1994",
    headquarters: "Seattle, Washington",
  },
  {
    name: "Microsoft",
    logo: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/%40%20partner-style-2%20%282%29-5QJm2dQmREEbXExQnYRIMD6v7DCK7L.png",
    website: "https://microsoft.com",
    description: "Leading provider of software, cloud services, and hardware.",
    employees: "181,000+",
    founded: "1975",
    headquarters: "Redmond, Washington",
  },
  {
    name: "Uber",
    logo: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/%40%20partner-style-2%20%283%29-bZqy4gHAHR5qEbsfk7XT7NkraLKu0F.png",
    website: "https://uber.com",
    description: "Revolutionary ride-sharing and delivery platform.",
    employees: "29,300+",
    founded: "2009",
    headquarters: "San Francisco, California",
  },
  {
    name: "Dropbox",
    logo: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/%40%20partner-style-2%20%284%29-19RNacUJUOdJEfLi5tQQslne89iZoJ.png",
    website: "https://dropbox.com",
    description: "Leading cloud storage and collaboration platform.",
    employees: "2,800+",
    founded: "2007",
    headquarters: "San Francisco, California",
  },
  {
    name: "Uzum Market",
    logo: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/%D0%A1%D0%BD%D0%B8%D0%BC%D0%BE%D0%BA%20%D1%8D%D0%BA%D1%80%D0%B0%D0%BD%D0%B0%202025-03-07%20%D0%B2%2017.26.58-T2Oa1NJ7sFVX0X2jBtZxcD6o6ncafa.png",
    website: "https://uzum.uz",
    description: "Innovative e-commerce platform in Central Asia.",
    employees: "1,000+",
    founded: "2020",
    headquarters: "Tashkent, Uzbekistan",
  },
  {
    name: "Wildberries",
    logo: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/%D0%A1%D0%BD%D0%B8%D0%BC%D0%BE%D0%BA%20%D1%8D%D0%BA%D1%80%D0%B0%D0%BD%D0%B0%202025-03-07%20%D0%B2%2017.32.28-wAAgITRWSySvfQQiffMeaq5mgFJukJ.png",
    website: "https://wildberries.ru",
    description: "Leading e-commerce platform in Russia and CIS.",
    employees: "45,000+",
    founded: "2004",
    headquarters: "Moscow, Russia",
  },
  {
    name: "Yandex",
    logo: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Yandex_Logo_2021-ciimyUKh6YWadpUtoYsL0as2Xi1doj.png",
    website: "https://yandex.com",
    description: "Leading technology company in Russia and CIS.",
    employees: "18,000+",
    founded: "1997",
    headquarters: "Moscow, Russia",
  },
]

const PartnerCard = ({ partner }) => {
  const { isOpen, onOpen, onClose } = useDisclosure()
  const [isHovered, setIsHovered] = useState(false)

  return (
    <>
      <MotionBox
        bg="white"
        p={6}
        borderRadius="xl"
        boxShadow="lg"
        cursor="pointer"
        onClick={onOpen}
        onMouseEnter={() => setIsHovered(true)}
        onMouseLeave={() => setIsHovered(false)}
        whileHover={{ scale: 1.05 }}
        whileTap={{ scale: 0.95 }}
        position="relative"
        overflow="hidden"
      >
        <MotionImage
          src={partner.logo}
          alt={partner.name}
          height="60px"
          objectFit="contain"
          mx="auto"
          filter={isHovered ? "none" : "grayscale(100%)"}
          transition="filter 0.3s ease"
        />
        <AnimatePresence>
          {isHovered && (
            <MotionBox
              position="absolute"
              top={0}
              left={0}
              right={0}
              bottom={0}
              bg="rgba(66, 153, 225, 0.9)"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              display="flex"
              alignItems="center"
              justifyContent="center"
              color="white"
              flexDirection="column"
              gap={2}
            >
              <Text fontWeight="bold">{partner.name}</Text>
              <Button
                size="sm"
                rightIcon={<ExternalLink size={16} />}
                onClick={(e) => {
                  e.stopPropagation()
                  window.open(partner.website, "_blank")
                }}
              >
                Visit Website
              </Button>
            </MotionBox>
          )}
        </AnimatePresence>
      </MotionBox>

      <Modal isOpen={isOpen} onClose={onClose} size="xl">
        <ModalOverlay backdropFilter="blur(5px)" />
        <ModalContent>
          <ModalHeader>
            <HStack spacing={4}>
              <Image src={partner.logo || "/placeholder.svg"} alt={partner.name} height="40px" />
              <Text>{partner.name}</Text>
            </HStack>
          </ModalHeader>
          <ModalCloseButton />
          <ModalBody pb={6}>
            <VStack align="stretch" spacing={4}>
              <Text fontSize="lg">{partner.description}</Text>

              <Box bg="gray.50" p={4} borderRadius="md">
                <VStack align="stretch" spacing={3}>
                  <HStack>
                    <Globe size={20} />
                    <Text fontWeight="bold">Headquarters:</Text>
                    <Text>{partner.headquarters}</Text>
                  </HStack>
                  <HStack>
                    <Users size={20} />
                    <Text fontWeight="bold">Employees:</Text>
                    <Text>{partner.employees}</Text>
                  </HStack>
                  <HStack>
                    <Award size={20} />
                    <Text fontWeight="bold">Founded:</Text>
                    <Text>{partner.founded}</Text>
                  </HStack>
                </VStack>
              </Box>

              <Button
                as={Link}
                href={partner.website}
                target="_blank"
                colorScheme="blue"
                rightIcon={<ExternalLink />}
                isExternal
              >
                Visit {partner.name} Website
              </Button>
            </VStack>
          </ModalBody>
        </ModalContent>
      </Modal>
    </>
  )
}

const Partners = () => {
  const containerRef = useRef(null)

  return (
    <Box as="section" py={20} bg="gray.50">
      <Container maxW="container.xl" ref={containerRef}>
        <VStack spacing={8} mb={12}>
          <MotionHeading
            as="h2"
            fontSize={{ base: "3xl", md: "4xl" }}
            textAlign="center"
            initial={{ opacity: 0, y: -20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
          >
            Partners
          </MotionHeading>
          <MotionText
            fontSize={{ base: "lg", md: "xl" }}
            color="gray.600"
            textAlign="center"
            maxW="2xl"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
          >
            Most calendars are designed for teams.
            <br />
            Slate is designed for freelancers
          </MotionText>
        </VStack>

        <SimpleGrid columns={{ base: 2, md: 3, lg: 4 }} spacing={8} mb={12}>
          {partners.map((partner, index) => (
            <MotionBox
              key={partner.name}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
            >
              <PartnerCard partner={partner} />
            </MotionBox>
          ))}
        </SimpleGrid>

        <MotionBox
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          textAlign="center"
        >
          <Button
            as={motion.button}
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            size="lg"
            colorScheme="blue"
            rightIcon={<ArrowRight />}
          >
            Try For Free
          </Button>
        </MotionBox>
      </Container>
    </Box>
  )
}

export default Partners

