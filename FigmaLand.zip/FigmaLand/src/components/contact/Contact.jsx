
import { useState, useRef, useEffect } from "react"
import {
  Box, Container, Heading, Text, Input, Textarea, Button, VStack, HStack, Flex, SimpleGrid, useToast, Icon, useColorModeValue,
  InputGroup, InputLeftElement, FormControl, FormLabel, FormErrorMessage, Image, Badge, Tooltip, IconButton, Divider,
} from "@chakra-ui/react"
import { motion, AnimatePresence } from "framer-motion"
import {
  MapPin, Phone, Mail, Send, User, AtSign, MessageSquare, Check, ExternalLink, Copy, Sparkles,
} from "lucide-react"

const MotionBox = motion(Box)
const MotionFlex = motion(Flex)
const MotionText = motion(Text)
const MotionImage = motion(Image)
const MotionBadge = motion(Badge)
const MotionButton = motion(Button)

export default function Contact() {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    message: "",
  })
  const [formErrors, setFormErrors] = useState({
    name: "",
    email: "",
    message: "",
  })
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [isTouched, setIsTouched] = useState({
    name: false,
    email: false,
    message: false,
  })
  const [formSuccess, setFormSuccess] = useState(false)
  const [mapHovered, setMapHovered] = useState(false)
  const [activeMarker, setActiveMarker] = useState(null)
  const [copiedField, setCopiedField] = useState(null)

  const toast = useToast()
  const mapRef = useRef(null)

  useEffect(() => {
    if (copiedField) {
      const timer = setTimeout(() => {
        setCopiedField(null)
      }, 2000)
      return () => clearTimeout(timer)
    }
  }, [copiedField])

  const validateField = (name, value) => {
    let error = ""

    if (name === "name" && !value.trim()) {
      error = "Name is required"
    } else if (name === "email") {
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
      if (!value.trim()) {
        error = "Email is required"
      } else if (!emailRegex.test(value)) {
        error = "Invalid email address"
      }
    } else if (name === "message" && !value.trim()) {
      error = "Message is required"
    }

    return error
  }

  const handleChange = (e) => {
    const { name, value } = e.target

    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }))

    if (!isTouched[name]) {
      setIsTouched((prev) => ({
        ...prev,
        [name]: true,
      }))
    }

    const error = validateField(name, value)
    setFormErrors((prev) => ({
      ...prev,
      [name]: error,
    }))
  }

  const handleBlur = (e) => {
    const { name, value } = e.target

    setIsTouched((prev) => ({
      ...prev,
      [name]: true,
    }))

    const error = validateField(name, value)
    setFormErrors((prev) => ({
      ...prev,
      [name]: error,
    }))
  }

  const handleSubmit = async (e) => {
    e.preventDefault()

    const errors = {
      name: validateField("name", formData.name),
      email: validateField("email", formData.email),
      message: validateField("message", formData.message),
    }

    setIsTouched({
      name: true,
      email: true,
      message: true,
    })

    setFormErrors(errors)

    if (errors.name || errors.email || errors.message) {
      toast({
        title: "Form has errors",
        description: "Please fix the errors before submitting",
        status: "error",
        duration: 3000,
      })
      return
    }

    setIsSubmitting(true)

    try {
      await new Promise((resolve) => setTimeout(resolve, 1500))

      setFormSuccess(true)

      toast({
        title: "Message sent!",
        description: "We'll get back to you soon.",
        status: "success",
        duration: 5000,
      })

      setTimeout(() => {
        setFormData({ name: "", email: "", message: "" })
        setIsTouched({ name: false, email: false, message: false })
        setFormSuccess(false)
      }, 5000)
    } catch (error) {
      toast({
        title: "Error",
        description: "Please try again later.",
        status: "error",
        duration: 3000,
      })
    } finally {
      setIsSubmitting(false)
    }
  }

  const handleCopyText = (text, field) => {
    navigator.clipboard.writeText(text)
    setCopiedField(field)
    toast({
      title: "Copied to clipboard",
      status: "success",
      duration: 2000,
      isClosable: true,
    })
  }

  const mapMarkers = [
    {
      id: "office",
      label: "Main Office",
      position: { top: "40%", left: "50%" },
      info: "Hayes Valley, San Francisco, CA",
    },
    {
      id: "cafe",
      label: "Coffee Shop",
      position: { top: "30%", left: "65%" },
      info: "Great place for meetings",
    },
    {
      id: "park",
      label: "City Park",
      position: { top: "55%", left: "35%" },
      info: "Relaxing outdoor space",
    },
  ]

  const bgColor = useColorModeValue("gray.50", "gray.900")
  const cardBg = useColorModeValue("white", "gray.800")
  const inputBg = useColorModeValue("gray.100", "gray.700")
  const borderColor = useColorModeValue("gray.200", "gray.600")
  const labelColor = useColorModeValue("gray.700", "gray.300")
  const accentGradient = "linear(to-r, blue.400, purple.500)"
  const markerBg = useColorModeValue("white", "gray.700")
  const markerShadow = useColorModeValue("lg", "dark-lg")

  const Particles = () => (
    <>
      {[...Array(15)].map((_, i) => (
        <MotionBox
          key={i}
          position="absolute"
          width={Math.random() * 12 + 2}
          height={Math.random() * 12 + 2}
          borderRadius="full"
          bg={i % 3 === 0 ? "blue.400" : i % 3 === 1 ? "purple.400" : "teal.400"}
          opacity={0.2}
          initial={{
            x: Math.random() * 100 + "%",
            y: Math.random() * 100 + "%",
          }}
          animate={{
            x: [Math.random() * 100 + "%", Math.random() * 100 + "%", Math.random() * 100 + "%"],
            y: [Math.random() * 100 + "%", Math.random() * 100 + "%", Math.random() * 100 + "%"],
            opacity: [0.1, 0.3, 0.1],
            scale: [1, 1.2, 1],
          }}
          transition={{
            duration: Math.random() * 20 + 10,
            repeat: Number.POSITIVE_INFINITY,
            ease: "linear",
          }}
        />
      ))}
    </>
  )

  return (
    <Box as="section" py={20} bg={bgColor} position="relative" overflow="hidden">
      <Box position="absolute" top={0} left={0} right={0} bottom={0} overflow="hidden" opacity={0.5}>
        <Particles />
      </Box>

      <Container maxW="container.xl" position="relative" zIndex={1}>
        <VStack spacing={12}>
          <MotionBox
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            textAlign="center"
          >
            <MotionBadge
              colorScheme="blue"
              px={3}
              py={1}
              borderRadius="full"
              mb={4}
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 0.3, duration: 0.5 }}
            >
              Get in touch
            </MotionBadge>

            <Heading as="h2" fontSize={{ base: "4xl", md: "5xl" }} bgGradient={accentGradient} bgClip="text" mb={4}>
              Contact Us
            </Heading>

            <MotionText
              fontSize="xl"
              color="gray.500"
              maxW="xl"
              mx="auto"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2, duration: 0.5 }}
            >
              Have questions or need assistance? Our team is here to help you with anything you need.
            </MotionText>
          </MotionBox>

          <SimpleGrid columns={{ base: 1, lg: 2 }} spacing={10} w="full">
            <MotionBox
              initial={{ opacity: 0, x: -30 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.5, delay: 0.2 }}
            >
              <Box
                as="form"
                onSubmit={handleSubmit}
                bg={cardBg}
                p={8}
                borderRadius="xl"
                boxShadow="xl"
                position="relative"
                overflow="hidden"
              >
                <Box
                  position="absolute"
                  top="-20px"
                  right="-20px"
                  width="100px"
                  height="100px"
                  borderRadius="full"
                  bgGradient={accentGradient}
                  opacity="0.1"
                />

                <Box
                  position="absolute"
                  bottom="-30px"
                  left="-30px"
                  width="120px"
                  height="120px"
                  borderRadius="full"
                  bgGradient="linear(to-r, teal.400, blue.500)"
                  opacity="0.1"
                />

                <AnimatePresence mode="wait">
                  {formSuccess ? (
                    <MotionBox
                      key="success"
                      initial={{ opacity: 0, scale: 0.8 }}
                      animate={{ opacity: 1, scale: 1 }}
                      exit={{ opacity: 0, scale: 0.8 }}
                      transition={{ duration: 0.5 }}
                      textAlign="center"
                      py={10}
                    >
                      <MotionBox
                        width="80px"
                        height="80px"
                        borderRadius="full"
                        bg="green.100"
                        color="green.500"
                        display="flex"
                        alignItems="center"
                        justifyContent="center"
                        mx="auto"
                        mb={6}
                        initial={{ scale: 0 }}
                        animate={{ scale: [0, 1.2, 1] }}
                        transition={{ duration: 0.5, delay: 0.2 }}
                      >
                        <Icon as={Check} boxSize={10} />
                      </MotionBox>

                      <Heading size="lg" mb={4}>
                        Message Sent!
                      </Heading>

                      <Text color="gray.500" mb={8}>
                        Thank you for reaching out. We'll get back to you as soon as possible.
                      </Text>

                      <MotionButton
                        colorScheme="blue"
                        leftIcon={<Sparkles size={16} />}
                        onClick={() => setFormSuccess(false)}
                        whileHover={{ scale: 1.05 }}
                        whileTap={{ scale: 0.95 }}
                      >
                        Send Another Message
                      </MotionButton>
                    </MotionBox>
                  ) : (
                    <MotionBox
                      key="form"
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      exit={{ opacity: 0 }}
                      transition={{ duration: 0.5 }}
                    >
                      <VStack spacing={6} align="stretch">
                        <FormControl isInvalid={isTouched.name && formErrors.name} isRequired>
                          <FormLabel color={labelColor}>Your Name</FormLabel>
                          <InputGroup>
                            <InputLeftElement pointerEvents="none">
                              <Icon as={User} color="gray.500" />
                            </InputLeftElement>
                            <Input
                              name="name"
                              placeholder="John Doe"
                              value={formData.name}
                              onChange={handleChange}
                              onBlur={handleBlur}
                              bg={inputBg}
                              borderColor={borderColor}
                              _focus={{
                                borderColor: "blue.400",
                                boxShadow: "0 0 0 1px blue.400",
                              }}
                              _hover={{
                                borderColor: "blue.300",
                              }}
                              transition="all 0.3s"
                            />
                          </InputGroup>
                          <FormErrorMessage>{formErrors.name}</FormErrorMessage>
                        </FormControl>

                        <FormControl isInvalid={isTouched.email && formErrors.email} isRequired>
                          <FormLabel color={labelColor}>Your Email</FormLabel>
                          <InputGroup>
                            <InputLeftElement pointerEvents="none">
                              <Icon as={AtSign} color="gray.500" />
                            </InputLeftElement>
                            <Input
                              name="email"
                              type="email"
                              placeholder="john@example.com"
                              value={formData.email}
                              onChange={handleChange}
                              onBlur={handleBlur}
                              bg={inputBg}
                              borderColor={borderColor}
                              _focus={{
                                borderColor: "blue.400",
                                boxShadow: "0 0 0 1px blue.400",
                              }}
                              _hover={{
                                borderColor: "blue.300",
                              }}
                              transition="all 0.3s"
                            />
                          </InputGroup>
                          <FormErrorMessage>{formErrors.email}</FormErrorMessage>
                        </FormControl>

                        <FormControl isInvalid={isTouched.message && formErrors.message} isRequired>
                          <FormLabel color={labelColor}>Your Message</FormLabel>
                          <InputGroup>
                            <InputLeftElement pointerEvents="none" h="auto" pt={2}>
                              <Icon as={MessageSquare} color="gray.500" />
                            </InputLeftElement>
                            <Textarea
                              name="message"
                              placeholder="How can we help you?"
                              value={formData.message}
                              onChange={handleChange}
                              onBlur={handleBlur}
                              bg={inputBg}
                              borderColor={borderColor}
                              pl={10}
                              minH="150px"
                              _focus={{
                                borderColor: "blue.400",
                                boxShadow: "0 0 0 1px blue.400",
                              }}
                              _hover={{
                                borderColor: "blue.300",
                              }}
                              transition="all 0.3s"
                            />
                          </InputGroup>
                          <FormErrorMessage>{formErrors.message}</FormErrorMessage>
                        </FormControl>

                        <MotionButton
                          type="submit"
                          colorScheme="blue"
                          size="lg"
                          w="full"
                          isLoading={isSubmitting}
                          loadingText="Sending..."
                          rightIcon={<Send size={16} />}
                          mt={4}
                          bgGradient={accentGradient}
                          _hover={{
                            bgGradient: "linear(to-r, blue.500, purple.600)",
                            transform: "translateY(-2px)",
                            boxShadow: "lg",
                          }}
                          whileHover={{ scale: 1.02 }}
                          whileTap={{ scale: 0.98 }}
                          transition={{ duration: 0.2 }}
                        >
                          Send Message
                        </MotionButton>
                      </VStack>
                    </MotionBox>
                  )}
                </AnimatePresence>
              </Box>
            </MotionBox>

            <MotionBox
              ref={mapRef}
              initial={{ opacity: 0, x: 30 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.5, delay: 0.2 }}
              borderRadius="xl"
              overflow="hidden"
              boxShadow="xl"
              bg={cardBg}
              position="relative"
              height={{ base: "300px", md: "400px", lg: "100%" }}
              onMouseEnter={() => setMapHovered(true)}
              onMouseLeave={() => {
                setMapHovered(false)
                setActiveMarker(null)
              }}
            >
              <MotionImage
                src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/%40%20map%20screen-LPfNyGVqui9Pxxfzadu4LhKTPPKbLi.png"
                alt="Map of San Francisco"
                width="100%"
                height="100%"
                objectFit="cover"
                initial={{ scale: 1 }}
                animate={{
                  scale: mapHovered ? 1.05 : 1,
                  filter: mapHovered ? "brightness(1.1) contrast(1.1)" : "brightness(1) contrast(1)",
                }}
                transition={{ duration: 0.5 }}
              />

              <Box
                position="absolute"
                top={0}
                left={0}
                right={0}
                bottom={0}
                bgGradient={mapHovered ? "linear(to-br, blue.500, purple.500)" : "none"}
                opacity={mapHovered ? 0.2 : 0}
                transition="opacity 0.3s"
              />

              <Box
                position="absolute"
                top={0}
                left={0}
                right={0}
                bottom={0}
                backgroundImage="url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNDAiIGhlaWdodD0iNDAiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGRlZnM+PHBhdHRlcm4gaWQ9ImdyaWQiIHdpZHRoPSI0MCIgaGVpZ2h0PSI0MCIgcGF0dGVyblVuaXRzPSJ1c2VyU3BhY2VPblVzZSI+PHBhdGggZD0iTSAwIDEwIEwgNDAgMTAgTSAxMCAwIEwgMTAgNDAgTSAwIDIwIEwgNDAgMjAgTSAyMCAwIEwgMjAgNDAgTSAwIDMwIEwgNDAgMzAgTSAzMCAwIEwgMzAgNDAiIGZpbGw9Im5vbmUiIHN0cm9rZT0icmdiYSgxMjgsMTQwLDI1NSwwLjIpIiBzdHJva2Utd2lkdGg9IjEiLz48L3BhdHRlcm4+PC9kZWZzPjxyZWN0IHdpZHRoPSIxMDAlIiBoZWlnaHQ9IjEwMCUiIGZpbGw9InVybCgjZ3JpZCkiLz48L3N2Zz4=')"
                opacity={mapHovered ? 0.8 : 0.4}
                transition="opacity 0.3s"
              />

              {mapMarkers.map((marker) => (
                <MotionBox
                  key={marker.id}
                  position="absolute"
                  top={marker.position.top}
                  left={marker.position.left}
                  transform="translate(-50%, -50%)"
                  zIndex={2}
                  initial={{ scale: 1 }}
                  animate={{
                    scale: activeMarker === marker.id ? 1.2 : 1,
                    y: activeMarker === marker.id ? -5 : 0,
                  }}
                  transition={{ duration: 0.3 }}
                >
                  <MotionBox
                    position="absolute"
                    width="40px"
                    height="40px"
                    borderRadius="full"
                    bg="rgba(66, 153, 225, 0.3)"
                    top="50%"
                    left="50%"
                    transform="translate(-50%, -50%)"
                    animate={{
                      scale: [1, 1.3, 1],
                      opacity: [0.7, 0.5, 0.7],
                    }}
                    transition={{
                      duration: 2,
                      repeat: Number.POSITIVE_INFINITY,
                      ease: "easeInOut",
                    }}
                  />

                  <MotionBox
                    width="20px"
                    height="20px"
                    borderRadius="full"
                    bg="blue.500"
                    boxShadow="0 0 10px rgba(66, 153, 225, 0.8)"
                    cursor="pointer"
                    onClick={() => setActiveMarker(activeMarker === marker.id ? null : marker.id)}
                    onMouseEnter={() => setActiveMarker(marker.id)}
                    onMouseLeave={() => !mapHovered && setActiveMarker(null)}
                  />

                  <AnimatePresence>
                    {(activeMarker === marker.id || (mapHovered && marker.id === "office")) && (
                      <MotionBox
                        position="absolute"
                        bottom="100%"
                        left="50%"
                        transform="translateX(-50%)"
                        mb={2}
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: 5 }}
                        transition={{ duration: 0.2 }}
                      >
                        <Box
                          bg={markerBg}
                          color="gray.800"
                          px={3}
                          py={2}
                          borderRadius="md"
                          boxShadow={markerShadow}
                          whiteSpace="nowrap"
                        >
                          <Text fontWeight="medium">{marker.label}</Text>
                          <Text fontSize="xs" color="gray.500">
                            {marker.info}
                          </Text>
                        </Box>
                        <Box
                          position="absolute"
                          bottom="-6px"
                          left="50%"
                          transform="translateX(-50%)"
                          width={0}
                          height={0}
                          borderLeft="6px solid transparent"
                          borderRight="6px solid transparent"
                          borderTop="6px solid"
                          borderTopColor={markerBg}
                        />
                      </MotionBox>
                    )}
                  </AnimatePresence>
                </MotionBox>
              ))}

              <AnimatePresence>
                {mapHovered && (
                  <MotionButton
                    position="absolute"
                    bottom="20px"
                    right="20px"
                    size="sm"
                    bg="white"
                    color="gray.800"
                    boxShadow="md"
                    rightIcon={<ExternalLink size={14} />}
                    _hover={{ bg: "gray.100" }}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: 10 }}
                    transition={{ duration: 0.2 }}
                    onClick={() => window.open("https://maps.google.com/?q=Hayes+Valley,San+Francisco", "_blank")}
                  >
                    View Larger Map
                  </MotionButton>
                )}
              </AnimatePresence>
            </MotionBox>
          </SimpleGrid>

          <SimpleGrid columns={{ base: 1, md: 3 }} spacing={8} w="full">
            {[
              {
                icon: MapPin,
                title: "Our Location",
                content: "Hayes Valley, San Francisco, CA",
                copyText: "Hayes Valley, San Francisco, CA",
                id: "address",
              },
              {
                icon: Phone,
                title: "Phone Number",
                content: "(843) 555-0130",
                copyText: "(843) 555-0130",
                id: "phone",
              },
              {
                icon: Mail,
                title: "Email Address",
                content: "contact@figmaland.com",
                copyText: "contact@figmaland.com",
                id: "email",
              },
            ].map((item, index) => (
              <MotionBox
                key={item.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: 0.3 + index * 0.1 }}
                whileHover={{ y: -5, boxShadow: "xl" }}
              >
                <Box bg={cardBg} p={6} borderRadius="lg" boxShadow="md" height="100%" transition="all 0.3s">
                  <VStack spacing={4} align="flex-start">
                    <Flex
                      w="50px"
                      h="50px"
                      borderRadius="lg"
                      bg="blue.50"
                      color="blue.500"
                      align="center"
                      justify="center"
                    >
                      <Icon as={item.icon} boxSize={6} />
                    </Flex>

                    <Box>
                      <Text fontWeight="bold" fontSize="lg" mb={1}>
                        {item.title}
                      </Text>
                      <Text color="gray.500">{item.content}</Text>
                    </Box>

                    <HStack>
                      <Tooltip label="Copy to clipboard">
                        <IconButton
                          icon={copiedField === item.id ? <Check size={16} /> : <Copy size={16} />}
                          size="sm"
                          variant="ghost"
                          colorScheme="blue"
                          onClick={() => handleCopyText(item.copyText, item.id)}
                          aria-label="Copy to clipboard"
                        />
                      </Tooltip>
                    </HStack>
                  </VStack>
                </Box>
              </MotionBox>
            ))}
          </SimpleGrid>
        </VStack>
      </Container>
    </Box>
  )
}

