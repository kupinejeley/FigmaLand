
import { useState, useRef } from "react"
import {
  Box, Container, SimpleGrid, VStack, Text, Link, HStack, Icon,Input, Button, Flex, Heading, Divider,  useToast,
  FormControl, FormErrorMessage, InputGroup, InputRightElement, useDisclosure, Modal, ModalOverlay, ModalContent,
  ModalHeader, ModalBody, ModalCloseButton, List, ListItem, ListIcon,
} from "@chakra-ui/react"
import { motion, useInView, AnimatePresence } from "framer-motion"
import { MapPin, Phone, Twitter, Facebook, Linkedin, Send, ArrowRight, ChevronRight, Mail, Globe, Check, ExternalLink, Star, Users, Calendar, Clock, Shield } from 'lucide-react'

const MotionBox = motion(Box)
const MotionText = motion(Text)
const MotionFlex = motion(Flex)
const MotionHeading = motion(Heading)
const MotionContainer = motion(Container)
const MotionButton = motion(Button)

const Features = () => {
  const [email, setEmail] = useState("")
  const [emailError, setEmailError] = useState("")
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [isSubscribed, setIsSubscribed] = useState(false)
  const [activeSection, setActiveSection] = useState(null)
  
  const containerRef = useRef(null)
  const isInView = useInView(containerRef, { once: true, margin: "-100px" })
  const toast = useToast()
  const { isOpen, onOpen, onClose } = useDisclosure()
  const [modalContent, setModalContent] = useState({ title: "", content: "" })

  const bg = "gray.900"
  const textColor = "gray.100"
  const mutedColor = "gray.400"
  const accentColor = "blue.400"
  const accentGradient = "linear(to-r, blue.400, purple.500)"
  const cardBg = "whiteAlpha.100"
  const inputBg = "whiteAlpha.100"
  const buttonBg = "blue.500"
  const hoverBg = "blue.600"
  const modalBg = "gray.800"

  const pages = [
    { name: "Home", path: "/" },
    { name: "Product", path: "/product" },
    { name: "Pricing", path: "/pricing" },
    { name: "About", path: "/about" },
    { name: "Contact", path: "/contact" }
  ]
  
  const tomothyTeam = [
    { name: "Eleanor Edwards", role: "UI Designer" },
    { name: "Ted Robertson", role: "Frontend Developer" },
    { name: "Annette Russell", role: "Product Manager" },
    { name: "Jennie Mckinney", role: "UX Researcher" },
    { name: "Gloria Richards", role: "Backend Developer" }
  ]
  
  const janeTeam = [
    { name: "Philip Jones", role: "Marketing Director" },
    { name: "Product", role: "Product Team" },
    { name: "Colleen Russell", role: "Customer Support" },
    { name: "Marvin Hawkins", role: "DevOps Engineer" },
    { name: "Bruce Simmmons", role: "QA Specialist" }
  ]

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
        delayChildren: 0.3,
      },
    },
  }

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { 
      opacity: 1, 
      y: 0,
      transition: {
        type: "spring",
        stiffness: 100,
        damping: 10
      }
    },
  }

  const fadeInUpVariants = {
    hidden: { opacity: 0, y: 40 },
    visible: { 
      opacity: 1, 
      y: 0,
      transition: {
        duration: 0.8,
        ease: "easeOut"
      }
    },
  }

  const logoVariants = {
    hidden: { opacity: 0, scale: 0.8 },
    visible: { 
      opacity: 1, 
      scale: 1,
      transition: {
        duration: 0.5,
        ease: "easeOut"
      }
    },
  }

  const pulseVariants = {
    initial: { scale: 1 },
    pulse: { 
      scale: [1, 1.05, 1],
      transition: {
        duration: 2,
        repeat: Infinity,
        repeatType: "reverse"
      }
    }
  }

  const validateEmail = (email) => {
    const re = /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/
    return re.test(String(email).toLowerCase())
  }

  const handleSubscribe = () => {
    if (!email) {
      setEmailError("Email is required")
      return
    }
    
    if (!validateEmail(email)) {
      setEmailError("Please enter a valid email")
      return
    }
    
    setEmailError("")
    setIsSubmitting(true)
    
    setTimeout(() => {
      setIsSubmitting(false)
      setIsSubscribed(true)
      
      toast({
        title: "Subscription successful!",
        description: "Thank you for subscribing to our newsletter.",
        status: "success",
        duration: 5000,
        isClosable: true,
        position: "top",
      })
      
      setTimeout(() => {
        setEmail("")
        setIsSubscribed(false)
      }, 3000)
    }, 1500)
  }

  const handleNavigation = (path) => {
    toast({
      title: "Navigation",
      description: `Navigating to ${path}`,
      status: "info",
      duration: 2000,
      isClosable: true,
      position: "top",
    })
  }

  const handleSocialClick = (platform) => {
    toast({
      title: "Social Media",
      description: `Opening ${platform} profile`,
      status: "info",
      duration: 2000,
      isClosable: true,
      position: "top",
    })
  }

  const handleTeamMemberClick = (member, team) => {
    setModalContent({
      title: member.name,
      content: {
        role: member.role,
        team: team,
        bio: `${member.name} is an experienced ${member.role} with over 5 years of industry experience. They specialize in creating innovative solutions and are a key member of our ${team} team.`,
        projects: ["Project Alpha", "Project Beta", "Project Gamma"],
        skills: ["Leadership", "Communication", "Technical Expertise", "Problem Solving"]
      }
    })
    onOpen()
  }

  const handleContactClick = (type, value) => {
    let action = ""
    
    switch(type) {
      case "address":
        action = "Opening map location"
        window.open(`https://maps.google.com/?q=${value}`, "_blank")
        break
      case "phone":
        action = "Calling"
        window.open(`tel:${value}`, "_blank")
        break
      case "email":
        action = "Sending email to"
        window.open(`mailto:${value}`, "_blank")
        break
      case "website":
        action = "Visiting"
        window.open(`https://${value}`, "_blank")
        break
      default:
        action = "Contacting"
    }
    
    toast({
      title: "Contact Action",
      description: `${action} ${value}`,
      status: "info",
      duration: 2000,
      isClosable: true,
      position: "top",
    })
  }

  return (
    <Box 
      as="section" 
      bg={bg} 
      color={textColor} 
      py={20}
      position="relative"
      overflow="hidden"
      ref={containerRef}
    >
      <Box 
        position="absolute" 
        top="10%" 
        left="5%" 
        width="300px" 
        height="300px" 
        borderRadius="full" 
        bgGradient="linear(to-r, blue.900, purple.900)" 
        opacity="0.15" 
        filter="blur(60px)"
      />
      
      <Box 
        position="absolute" 
        bottom="10%" 
        right="5%" 
        width="250px" 
        height="250px" 
        borderRadius="full" 
        bgGradient="linear(to-r, purple.900, blue.900)" 
        opacity="0.15" 
        filter="blur(60px)"
      />
      
      <Box 
        position="absolute" 
        top="40%" 
        right="20%" 
        width="200px" 
        height="200px" 
        borderRadius="full" 
        bgGradient="linear(to-r, teal.900, blue.900)" 
        opacity="0.1" 
        filter="blur(60px)"
      />
      
      <Box
        position="absolute"
        top={0}
        left={0}
        right={0}
        bottom={0}
        backgroundImage="url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGRlZnM+PHBhdHRlcm4gaWQ9ImdyaWQiIHdpZHRoPSI2MCIgaGVpZ2h0PSI2MCIgcGF0dGVyblVuaXRzPSJ1c2VyU3BhY2VPblVzZSI+PHBhdGggZD0iTSA2MCAwIEwgMCAwIDAgNjAiIGZpbGw9Im5vbmUiIHN0cm9rZT0icmdiYSgyNTUsMjU1LDI1NSwwLjAzKSIgc3Ryb2tlLXdpZHRoPSIxIi8+PC9wYXR0ZXJuPjwvZGVmcz48cmVjdCB3aWR0aD0iMTAwJSIgaGVpZ2h0PSIxMDAlIiBmaWxsPSJ1cmwoI2dyaWQpIi8+PC9zdmc+')"
        opacity={0.4}
      />
      
      <MotionContainer 
        maxW="container.xl" 
        position="relative" 
        zIndex={1}
        variants={containerVariants}
        initial="hidden"
        animate={isInView ? "visible" : "hidden"}
      >
        <MotionFlex
          direction={{ base: "column", md: "row" }}
          justify="space-between"
          align={{ base: "center", md: "flex-start" }}
          mb={16}
          variants={fadeInUpVariants}
        >
          <MotionBox 
            variants={logoVariants} 
            mb={{ base: 8, md: 0 }}
            initial="initial"
            animate="pulse"
          >
            <Heading 
              as="h2" 
              fontSize="3xl" 
              bgGradient={accentGradient} 
              bgClip="text"
              letterSpacing="tight"
              cursor="pointer"
              onClick={() => handleNavigation("/")}
              _hover={{ transform: "scale(1.05)" }}
              transition="transform 0.3s"
            >
              FIGMALAND
            </Heading>
          </MotionBox>
          
          <MotionBox 
            maxW={{ base: "full", md: "400px" }}
            w="full"
            variants={itemVariants}
          >
            <Text fontSize="lg" fontWeight="medium" mb={3}>
              Subscribe to our newsletter
            </Text>
            
            <FormControl isInvalid={!!emailError}>
              <InputGroup size="lg">
                <Input
                  placeholder="Your email address"
                  value={email}
                  onChange={(e) => {
                    setEmail(e.target.value)
                    if (emailError) setEmailError("")
                  }}
                  bg={inputBg}
                  border="1px solid"
                  borderColor="whiteAlpha.200"
                  _placeholder={{ color: "whiteAlpha.500" }}
                  _hover={{ bg: "whiteAlpha.200", borderColor: "whiteAlpha.300" }}
                  _focus={{ bg: "whiteAlpha.200", borderColor: accentColor, boxShadow: `0 0 0 1px ${accentColor}` }}
                  pr="4.5rem"
                  disabled={isSubmitting || isSubscribed}
                />
                <InputRightElement width="4.5rem">
                  <Button
                    h="1.75rem"
                    size="sm"
                    bg={buttonBg}
                    _hover={{ bg: hoverBg }}
                    onClick={handleSubscribe}
                    isLoading={isSubmitting}
                    disabled={isSubscribed}
                  >
                    {isSubscribed ? <Check size={16} /> : <Send size={16} />}
                  </Button>
                </InputRightElement>
              </InputGroup>
              <FormErrorMessage>{emailError}</FormErrorMessage>
            </FormControl>
          </MotionBox>
        </MotionFlex>
        
        <Divider borderColor="whiteAlpha.200" mb={16} />
        
        <SimpleGrid columns={{ base: 1, md: 2, lg: 4 }} spacing={{ base: 10, lg: 16 }}>
          <MotionBox variants={itemVariants}>
            <MotionText
              fontSize="xl"
              fontWeight="bold"
              mb={6}
              bgGradient={accentGradient}
              bgClip="text"
            >
              Pages
            </MotionText>
            <VStack align="flex-start" spacing={4}>
              {pages.map((page) => (
                <MotionBox
                  key={page.name}
                  variants={itemVariants}
                  whileHover={{ x: 5, color: accentColor }}
                  transition={{ duration: 0.2 }}
                  cursor="pointer"
                  onClick={() => handleNavigation(page.path)}
                >
                  <HStack spacing={1}>
                    <Icon as={ChevronRight} boxSize={4} opacity={0.5} />
                    <Text color={mutedColor}>{page.name}</Text>
                  </HStack>
                </MotionBox>
              ))}
            </VStack>
          </MotionBox>

          <MotionBox variants={itemVariants}>
            <MotionText
              fontSize="xl"
              fontWeight="bold"
              mb={6}
              bgGradient={accentGradient}
              bgClip="text"
            >
              Tomothy
            </MotionText>
            <VStack align="flex-start" spacing={4}>
              {tomothyTeam.map((member) => (
                <MotionBox
                  key={member.name}
                  variants={itemVariants}
                  whileHover={{ x: 5, color: accentColor }}
                  transition={{ duration: 0.2 }}
                  cursor="pointer"
                  onClick={() => handleTeamMemberClick(member, "Tomothy")}
                  onMouseEnter={() => setActiveSection(member.name)}
                  onMouseLeave={() => setActiveSection(null)}
                >
                  <HStack spacing={2}>
                    <Text color={activeSection === member.name ? accentColor : mutedColor}>
                      {member.name}
                    </Text>
                    {activeSection === member.name && (
                      <Icon as={ExternalLink} boxSize={3} color={accentColor} />
                    )}
                  </HStack>
                </MotionBox>
              ))}
            </VStack>
          </MotionBox>

          <MotionBox variants={itemVariants}>
            <MotionText
              fontSize="xl"
              fontWeight="bold"
              mb={6}
              bgGradient={accentGradient}
              bgClip="text"
            >
              Jane Black
            </MotionText>
            <VStack align="flex-start" spacing={4}>
              {janeTeam.map((member) => (
                <MotionBox
                  key={member.name}
                  variants={itemVariants}
                  whileHover={{ x: 5, color: accentColor }}
                  transition={{ duration: 0.2 }}
                  cursor="pointer"
                  onClick={() => handleTeamMemberClick(member, "Jane Black")}
                  onMouseEnter={() => setActiveSection(member.name)}
                  onMouseLeave={() => setActiveSection(null)}
                >
                  <HStack spacing={2}>
                    <Text color={activeSection === member.name ? accentColor : mutedColor}>
                      {member.name}
                    </Text>
                    {activeSection === member.name && (
                      <Icon as={ExternalLink} boxSize={3} color={accentColor} />
                    )}
                  </HStack>
                </MotionBox>
              ))}
            </VStack>
          </MotionBox>

          <MotionBox variants={itemVariants}>
            <MotionText
              fontSize="xl"
              fontWeight="bold"
              mb={6}
              bgGradient={accentGradient}
              bgClip="text"
            >
              Contact Us
            </MotionText>
            <VStack align="flex-start" spacing={6}>
              <MotionBox
                variants={itemVariants}
                whileHover={{ x: 5 }}
                transition={{ duration: 0.2 }}
                cursor="pointer"
                onClick={() => handleContactClick("address", "7480 Mockingbird Hill")}
              >
                <HStack spacing={3} align="flex-start">
                  <Icon as={MapPin} boxSize={5} color={accentColor} mt={1} />
                  <Text color={mutedColor}>
                    7480 Mockingbird Hill undefined
                  </Text>
                </HStack>
              </MotionBox>

              <MotionBox
                variants={itemVariants}
                whileHover={{ x: 5 }}
                transition={{ duration: 0.2 }}
                cursor="pointer"
                onClick={() => handleContactClick("phone", "(239) 555-0108")}
              >
                <HStack spacing={3} align="flex-start">
                  <Icon as={Phone} boxSize={5} color={accentColor} mt={1} />
                  <Text color={mutedColor}>
                    (239) 555-0108
                  </Text>
                </HStack>
              </MotionBox>
              
              <MotionBox
                variants={itemVariants}
                whileHover={{ x: 5 }}
                transition={{ duration: 0.2 }}
                cursor="pointer"
                onClick={() => handleContactClick("email", "contact@figmaland.com")}
              >
                <HStack spacing={3} align="flex-start">
                  <Icon as={Mail} boxSize={5} color={accentColor} mt={1} />
                  <Text color={mutedColor}>
                    contact@figmaland.com
                  </Text>
                </HStack>
              </MotionBox>
              
              <MotionBox
                variants={itemVariants}
                whileHover={{ x: 5 }}
                transition={{ duration: 0.2 }}
                cursor="pointer"
                onClick={() => handleContactClick("website", "www.figmaland.com")}
              >
                <HStack spacing={3} align="flex-start">
                  <Icon as={Globe} boxSize={5} color={accentColor} mt={1} />
                  <Text color={mutedColor}>
                    www.figmaland.com
                  </Text>
                </HStack>
              </MotionBox>

              <HStack spacing={4} pt={2}>
                {[
                  { icon: Twitter, name: "Twitter" },
                  { icon: Facebook, name: "Facebook" },
                  { icon: Linkedin, name: "LinkedIn" }
                ].map((social, index) => (
                  <MotionBox
                    key={index}
                    variants={itemVariants}
                    whileHover={{ y: -5, scale: 1.1 }}
                    whileTap={{ scale: 0.95 }}
                  >
                    <Box
                      as="button"
                      onClick={() => handleSocialClick(social.name)}
                      aria-label={`Visit our ${social.name}`}
                    >
                      <Flex
                        align="center"
                        justify="center"
                        w="40px"
                        h="40px"
                        borderRadius="full"
                        bg={cardBg}
                        color={textColor}
                        _hover={{ bg: accentColor, color: "white" }}
                        transition="all 0.3s"
                      >
                        <Icon as={social.icon} boxSize={5} />
                      </Flex>
                    </Box>
                  </MotionBox>
                ))}
              </HStack>
            </VStack>
          </MotionBox>
        </SimpleGrid>
        
        <MotionFlex
          justify="center"
          mt={20}
          pt={8}
          borderTop="1px solid"
          borderColor="whiteAlpha.200"
          variants={fadeInUpVariants}
        >
          <Text fontSize="sm" color={mutedColor}>
            © {new Date().getFullYear()} FIGMALAND. All rights reserved.
          </Text>
        </MotionFlex>
      </MotionContainer>
      
      <Modal isOpen={isOpen} onClose={onClose} size="lg">
        <ModalOverlay backdropFilter="blur(8px)" />
        <ModalContent bg={modalBg} color={textColor}>
          <ModalHeader 
            bgGradient={accentGradient} 
            bgClip="text"
            borderBottom="1px solid"
            borderColor="whiteAlpha.200"
            pb={4}
          >
            {modalContent.title}
          </ModalHeader>
          <ModalCloseButton color={mutedColor} />
          <ModalBody py={6}>
            {modalContent.content && (
              <VStack align="stretch" spacing={6}>
                <HStack>
                  <Box 
                    bg={cardBg} 
                    p={3} 
                    borderRadius="md" 
                    borderLeft="3px solid" 
                    borderColor={accentColor}
                  >
                    <Text fontWeight="bold" color={accentColor}>Role</Text>
                    <Text>{modalContent.content.role}</Text>
                  </Box>
                  <Box 
                    bg={cardBg} 
                    p={3} 
                    borderRadius="md" 
                    borderLeft="3px solid" 
                    borderColor="purple.400"
                  >
                    <Text fontWeight="bold" color="purple.400">Team</Text>
                    <Text>{modalContent.content.team}</Text>
                  </Box>
                </HStack>
                
                <Box>
                  <Text fontWeight="bold" mb={2}>Biography</Text>
                  <Text color={mutedColor}>{modalContent.content.bio}</Text>
                </Box>
                
                <Box>
                  <Text fontWeight="bold" mb={2}>Projects</Text>
                  <List spacing={2}>
                    {modalContent.content.projects.map((project, index) => (
                      <ListItem key={index}>
                        <HStack>
                          <ListIcon as={Star} color={accentColor} />
                          <Text color={mutedColor}>{project}</Text>
                        </HStack>
                      </ListItem>
                    ))}
                  </List>
                </Box>
                
                <Box>
                  <Text fontWeight="bold" mb={2}>Skills</Text>
                  <HStack flexWrap="wrap" spacing={2}>
                    {modalContent.content.skills.map((skill, index) => (
                      <MotionBox
                        key={index}
                        px={3}
                        py={1}
                        bg={cardBg}
                        borderRadius="full"
                        fontSize="sm"
                        whileHover={{ scale: 1.05 }}
                        whileTap={{ scale: 0.95 }}
                        mb={2}
                      >
                        {skill}
                      </MotionBox>
                    ))}
                  </HStack>
                </Box>
                
                <MotionButton
                  colorScheme="blue"
                  rightIcon={<ArrowRight size={16} />}
                  onClick={onClose}
                  alignSelf="flex-end"
                  mt={4}
                  whileHover={{ x: 5 }}
                  whileTap={{ scale: 0.95 }}
                >
                  Close
                </MotionButton>
              </VStack>
            )}
          </ModalBody>
        </ModalContent>
      </Modal>
    </Box>
  )
}

export default Features
