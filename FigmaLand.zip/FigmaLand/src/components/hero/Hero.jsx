
import { useRef, useState, useEffect, useMemo } from "react"
import { Box, Container, Heading, Text, SimpleGrid, VStack, Image, Button, useDisclosure, Flex } from "@chakra-ui/react"
import { motion, useInView, useAnimation, AnimatePresence } from "framer-motion"
import { Square, PenTool, Zap, Play, X, ChevronRight } from "lucide-react"

const MotionBox = motion(Box)
const MotionHeading = motion(Heading)
const MotionText = motion(Text)
const MotionFlex = motion(Flex)

const FeatureCard = ({ icon: Icon, title, description, index }) => {
  const controls = useAnimation()
  const ref = useRef(null)
  const isInView = useInView(ref, { once: true, margin: "-50px" })
  const [isHovered, setIsHovered] = useState(false)

  useEffect(() => {
    if (isInView) {
      controls.start("visible")
    }
  }, [controls, isInView])

  return (
    <MotionBox
      ref={ref}
      initial="hidden"
      animate={controls}
      variants={{
        hidden: { opacity: 0, y: 50 },
        visible: { opacity: 1, y: 0, transition: { duration: 0.5, delay: index * 0.2 } },
      }}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      whileHover={{ scale: 1.05 }}
      whileTap={{ scale: 0.95 }}
    >
      <VStack
        spacing={6}
        align="center"
        textAlign="center"
        bg="white"
        p={8}
        borderRadius="xl"
        boxShadow="xl"
        transition="all 0.3s ease"
        position="relative"
        overflow="hidden"
        transform={`perspective(1000px) rotateY(${isHovered ? "10deg" : "0deg"})`}
        style={{
          transformStyle: "preserve-3d",
        }}
      >
        <MotionBox
          as="div"
          p={4}
          bg="blue.50"
          color="blue.500"
          borderRadius="full"
          initial={{ rotate: 0 }}
          animate={{ rotate: isHovered ? 360 : 0 }}
          transition={{ duration: 0.5 }}
          style={{
            transform: `translateZ(${isHovered ? "40px" : "0px"})`,
          }}
        >
          <Icon size={32} strokeWidth={1.5} />
        </MotionBox>
        <MotionHeading
          as="h3"
          fontSize="xl"
          fontWeight="600"
          color="gray.800"
          style={{
            transform: `translateZ(${isHovered ? "30px" : "0px"})`,
          }}
        >
          {title}
        </MotionHeading>
        <MotionText
          color="gray.600"
          fontSize="md"
          style={{
            transform: `translateZ(${isHovered ? "20px" : "0px"})`,
          }}
        >
          {description}
        </MotionText>
        <MotionFlex
          align="center"
          color="blue.500"
          fontWeight="bold"
          opacity={isHovered ? 1 : 0}
          transform={`translateY(${isHovered ? "0" : "20px"}) translateZ(${isHovered ? "40px" : "0px"})`}
          transition="all 0.3s ease"
        >
          Learn More <ChevronRight size={20} />
        </MotionFlex>
      </VStack>
    </MotionBox>
  )
}

const Features = () => {
  const ref = useRef(null)
  const isInView = useInView(ref, { once: true, margin: "-100px" })
  const controls = useAnimation()
  const { isOpen, onOpen, onClose } = useDisclosure()
  const [currentFeature, setCurrentFeature] = useState(0)

  useEffect(() => {
    if (isInView) {
      controls.start("visible")
    }
  }, [controls, isInView])

  const features = useMemo(
    () => [
      {
        icon: Square,
        title: "OpenType features Variable fonts",
        description: "Slate helps you see how many more days you need to work to reach your financial goal.",
      },
      {
        icon: PenTool,
        title: "Design with real data",
        description: "Slate helps you see how many more days you need to work to reach your financial goal.",
      },
      {
        icon: Zap,
        title: "Fastest way to take action",
        description: "Slate helps you see how many more days you need to work to reach your financial goal.",
      },
    ],
    [],
  )

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentFeature((prev) => (prev + 1) % features.length)
    }, 5000)
    return () => clearInterval(interval)
  }, [features])

  return (
    <Box as="section" py={20} bg="gray.50" ref={ref} overflow="hidden">
      <Container maxW="container.xl">
        <VStack spacing={6} mb={16}>
          <MotionHeading
            as="h2"
            fontSize={{ base: "3xl", md: "4xl" }}
            fontWeight="bold"
            textAlign="center"
            initial="hidden"
            animate={controls}
            variants={{
              hidden: { opacity: 0, y: -20 },
              visible: { opacity: 1, y: 0, transition: { duration: 0.5 } },
            }}
          >
            Features
          </MotionHeading>
          <MotionText
            fontSize={{ base: "lg", md: "xl" }}
            color="gray.600"
            textAlign="center"
            maxW="2xl"
            mx="auto"
            initial="hidden"
            animate={controls}
            variants={{
              hidden: { opacity: 0, y: 20 },
              visible: { opacity: 1, y: 0, transition: { duration: 0.5, delay: 0.2 } },
            }}
          >
            Most calendars are designed for teams.
            <br />
            Slate is designed for freelancers
          </MotionText>
        </VStack>

        <SimpleGrid columns={{ base: 1, md: 3 }} spacing={{ base: 10, md: 8 }} mb={20}>
          {features.map((feature, index) => (
            <FeatureCard key={index} {...feature} index={index} />
          ))}
        </SimpleGrid>

        <MotionBox
          position="relative"
          borderRadius="xl"
          overflow="hidden"
          boxShadow="2xl"
          initial="hidden"
          animate={controls}
          variants={{
            hidden: { opacity: 0, scale: 0.9 },
            visible: { opacity: 1, scale: 1, transition: { duration: 0.5, delay: 0.4 } },
          }}
          whileHover={{ scale: 1.02 }}
        >
          <Image
            src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/screen-Do1SWWVLQUtCGkG4EzJl9bIf4WTNeo.png"
            alt="Feature demonstration"
            w="full"
            h="auto"
          />
          <Box position="absolute" top="50%" left="50%" transform="translate(-50%, -50%)">
            <Button
              onClick={onOpen}
              bg="blue.500"
              color="white"
              size="lg"
              rounded="full"
              w="64px"
              h="64px"
              _hover={{ bg: "blue.600" }}
              _active={{ bg: "blue.700" }}
            >
              <Play size={24} />
            </Button>
          </Box>
          <AnimatePresence>
            <MotionBox
              key={currentFeature}
              position="absolute"
              bottom={0}
              left={0}
              right={0}
              bg="rgba(0,0,0,0.7)"
              p={4}
              color="white"
              initial={{ opacity: 0, y: 50 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 50 }}
              transition={{ duration: 0.5 }}
            >
              <Heading size="md" mb={2}>
                {features[currentFeature].title}
              </Heading>
              <Text fontSize="sm">{features[currentFeature].description}</Text>
            </MotionBox>
          </AnimatePresence>
        </MotionBox>

        {isOpen && (
          <MotionBox
            position="fixed"
            top={0}
            left={0}
            right={0}
            bottom={0}
            bg="rgba(0,0,0,0.8)"
            zIndex={9999}
            display="flex"
            alignItems="center"
            justifyContent="center"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
          >
            <MotionBox
              bg="white"
              p={4}
              borderRadius="md"
              position="relative"
              width="80%"
              maxWidth="800px"
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              transition={{ type: "spring", damping: 15 }}
            >
              <Button
                position="absolute"
                top={2}
                right={2}
                onClick={onClose}
                bg="transparent"
                _hover={{ bg: "gray.100" }}
              >
                <X size={24} />
              </Button>
              <Box
                as="iframe"
                src="https://www.youtube.com/embed/dQw4w9WgXcQ"
                width="100%"
                height="450px"
                frameBorder="0"
                allowFullScreen
              />
            </MotionBox>
          </MotionBox>
        )}
      </Container>
    </Box>
  )
}

export default Features

