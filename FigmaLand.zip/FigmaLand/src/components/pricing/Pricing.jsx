
import { useState, useRef, useEffect } from "react"
import {
  Box, Container, Heading, Text, Button, VStack, HStack, SimpleGrid, Badge,
  useDisclosure, Modal, ModalOverlay, ModalContent, ModalHeader, ModalBody, ModalCloseButton,
  FormControl, FormLabel, Input, InputGroup, InputLeftElement, Select, Tabs, TabList, 
  TabPanels, Tab, TabPanel, useToast, Flex, Image, Divider,  Icon, useColorModeValue,
} from "@chakra-ui/react"
import { motion, useAnimation, useInView } from "framer-motion"
import { CreditCard, CheckCircle, ShoppingBag, Globe, Shield, Sparkles, Star, ChevronRight } from "lucide-react"

const MotionBox = motion(Box)
const MotionButton = motion(Button)
const MotionHeading = motion(Heading)
const MotionText = motion(Text)
const MotionFlex = motion(Flex)
const MotionHStack = motion(HStack)

const pricingPlans = [
  {
    id: "free",
    name: "FREE",
    price: 0,
    description: "Perfect for individuals just getting started",
    features: [
      "Basic project templates",
      "2GB cloud storage",
      "Email support",
      "Access to community forums",
      "Limited API access",
    ],
    icon: Globe,
    popular: false,
    cta: "Get Started",
    gradient: "linear-gradient(135deg, #E0E0E0 0%, #F5F5F5 100%)",
  },
  {
    id: "standard",
    name: "STANDARD",
    price: 10,
    description: "Ideal for freelancers and small teams",
    features: [
      "All FREE features",
      "Unlimited project templates",
      "20GB cloud storage",
      "Priority email support",
      "Full API access",
    ],
    icon: Star,
    popular: true,
    cta: "Order Now",
    gradient: "linear-gradient(135deg, #60A5FA 0%, #3B82F6 100%)",
  },
  {
    id: "business",
    name: "BUSINESS",
    price: 99,
    description: "For professional teams and organizations",
    features: [
      "All STANDARD features",
      "Enterprise-grade security",
      "Unlimited cloud storage",
      "24/7 phone & email support",
      "Custom API integrations",
    ],
    icon: ShoppingBag,
    popular: false,
    cta: "Contact Sales",
    gradient: "linear-gradient(135deg, #1E293B 0%, #334155 100%)",
  },
]

const paymentMethods = [
  {
    id: "visa",
    name: "Visa",
    icon: "src/assets/Images/png-transparent-visa-logo-visa-electron-credit-card-debit-card-automated-teller-machine-visa-logo-blue-text-trademark.png",
  },
  {
    id: "mastercard",
    name: "MasterCard",
    icon: "src/assets/Images/kisspng-mastercard-credit-card-payment-card-number-visa-lo-advanced-dental-group-dental-care-with-a-heart-1713893243328.webp",
  },
  {
    id: "binance",
    name: "Binance",
    icon: "https://cdn.worldvectorlogo.com/logos/binance-logo.svg",
  },
]

const PricingCard = ({ plan, onSelectPlan, index }) => {
  const isPopular = plan.popular
  const ref = useRef(null)
  const isInView = useInView(ref, { once: true, margin: "-100px" })
  const controls = useAnimation()
  const [isHovered, setIsHovered] = useState(false)

  const baseBg = useColorModeValue("white", "gray.800")
  const popularBg = useColorModeValue("blue.50", "blue.900")
  const textColor = useColorModeValue("gray.800", "white")
  const lightTextColor = useColorModeValue("gray.600", "gray.300")

  useEffect(() => {
    if (isInView) {
      controls.start("visible")
    }
  }, [controls, isInView])

  return (
    <MotionBox
      ref={ref}
      bg={isPopular ? popularBg : baseBg}
      color={textColor}
      borderRadius="2xl"
      p={0}
      overflow="hidden"
      boxShadow={isHovered ? "2xl" : "xl"}
      position="relative"
      initial="hidden"
      animate={controls}
      variants={{
        hidden: { opacity: 0, y: 50 },
        visible: {
          opacity: 1,
          y: 0,
          transition: {
            duration: 0.6,
            delay: index * 0.2,
          },
        },
      }}
      onHoverStart={() => setIsHovered(true)}
      onHoverEnd={() => setIsHovered(false)}
      transform={isHovered ? "translateY(-15px)" : "none"}
      transition="all 0.3s ease"
      border="1px solid"
      borderColor={isPopular ? "blue.400" : "gray.200"}
      h="full"
    >
      <Box h="8px" w="full" bgGradient={plan.gradient} />

      {isPopular && (
        <Badge
          position="absolute"
          top={5}
          right={5}
          colorScheme="green"
          borderRadius="full"
          px={3}
          py={1}
          fontSize="xs"
          fontWeight="bold"
          bg="green.400"
          color="white"
          letterSpacing="wider"
          textTransform="uppercase"
          boxShadow="md"
        >
          Popular
        </Badge>
      )}

      <VStack spacing={6} align="center" p={8} h="full">
        <MotionBox
          animate={isHovered ? { y: [0, -10, 0] } : {}}
          transition={isHovered ? { duration: 1, repeat: 0 } : {}}
        >
          <Flex
            w="60px"
            h="60px"
            borderRadius="full"
            bg={isPopular ? "blue.400" : "gray.100"}
            color={isPopular ? "white" : "gray.600"}
            align="center"
            justify="center"
            mb={2}
          >
            <Icon as={plan.icon} boxSize={6} />
          </Flex>
        </MotionBox>

        <VStack spacing={2}>
          <Heading size="lg" textAlign="center" color={isPopular ? "blue.500" : textColor} letterSpacing="tight">
            {plan.name}
          </Heading>
          <Text color={lightTextColor} fontSize="sm" textAlign="center" fontWeight="medium">
            {plan.description}
          </Text>
        </VStack>

        <MotionHStack
          spacing={1}
          align="flex-start"
          initial={{ scale: 1 }}
          animate={isHovered ? { scale: 1.05 } : { scale: 1 }}
          transition={{ duration: 0.3 }}
        >
          <Text fontSize="xl" mt={1} fontWeight="medium">
            $
          </Text>
          <Heading
            size="4xl"
            fontWeight="bold"
            bgGradient={isPopular ? "linear(to-r, blue.400, blue.600)" : ""}
            bgClip={isPopular ? "text" : ""}
          >
            {plan.price}
          </Heading>
          <Text fontSize="md" mt={6} color={lightTextColor}>
            Per Month
          </Text>
        </MotionHStack>

        <Divider opacity={0.2} />

        <VStack spacing={4} align="stretch" w="full" flex="1">
          {plan.features.map((feature, index) => (
            <HStack key={index} spacing={3}>
              <Box color={isPopular ? "blue.400" : "green.400"}>
                <CheckCircle size={18} />
              </Box>
              <Text fontSize="sm" color={lightTextColor}>
                {feature}
              </Text>
            </HStack>
          ))}
        </VStack>

        <MotionButton
          colorScheme={isPopular ? "blue" : "gray"}
          variant={isPopular ? "solid" : "outline"}
          size="lg"
          w="full"
          rounded="xl"
          fontWeight="semibold"
          mt={4}
          h="56px"
          onClick={() => onSelectPlan(plan)}
          _hover={{
            transform: "translateY(-2px)",
            boxShadow: "lg",
          }}
          whileHover={{ scale: 1.03 }}
          whileTap={{ scale: 0.97 }}
          position="relative"
          overflow="hidden"
        >
          {plan.cta}
          {isPopular && (
            <MotionBox
              position="absolute"
              top="0"
              left="0"
              right="0"
              bottom="0"
              zIndex="-1"
              bgGradient="linear(to-r, blue.400, blue.500, blue.600)"
              initial={{ x: "-100%" }}
              animate={isHovered ? { x: "0%" } : { x: "-100%" }}
              transition={{ duration: 0.3 }}
            />
          )}
        </MotionButton>
      </VStack>
    </MotionBox>
  )
}

const PaymentModal = ({ isOpen, onClose, selectedPlan }) => {
  const [activeTab, setActiveTab] = useState(0)
  const [cardNumber, setCardNumber] = useState("")
  const [cardName, setCardName] = useState("")
  const [expiryMonth, setExpiryMonth] = useState("")
  const [expiryYear, setExpiryYear] = useState("")
  const [cvv, setCvv] = useState("")
  const [isSubmitting, setIsSubmitting] = useState(false)
  const toast = useToast()

  const formatCardNumber = (value) => {
    const v = value.replace(/\s+/g, "").replace(/[^0-9]/gi, "")
    const matches = v.match(/\d{4,16}/g)
    const match = (matches && matches[0]) || ""
    const parts = []

    for (let i = 0, len = match.length; i < len; i += 4) {
      parts.push(match.substring(i, i + 4))
    }

    if (parts.length) {
      return parts.join(" ")
    } else {
      return value
    }
  }

  const handleSubmit = (e) => {
    e.preventDefault()
    setIsSubmitting(true)

    if (cardNumber.replace(/\s/g, "").length !== 16) {
      toast({
        title: "Invalid card number",
        description: "Please enter a valid 16-digit card number",
        status: "error",
        duration: 3000,
        isClosable: true,
      })
      setIsSubmitting(false)
      return
    }

    if (!cardName) {
      toast({
        title: "Invalid name",
        description: "Please enter the cardholder name",
        status: "error",
        duration: 3000,
        isClosable: true,
      })
      setIsSubmitting(false)
      return
    }

    if (!expiryMonth || !expiryYear) {
      toast({
        title: "Invalid expiry date",
        description: "Please enter a valid expiry date",
        status: "error",
        duration: 3000,
        isClosable: true,
      })
      setIsSubmitting(false)
      return
    }

    if (cvv.length < 3) {
      toast({
        title: "Invalid CVV",
        description: "Please enter a valid CVV code",
        status: "error",
        duration: 3000,
        isClosable: true,
      })
      setIsSubmitting(false)
      return
    }

    setTimeout(() => {
      toast({
        title: "Payment successful!",
        description: `You have successfully purchased the ${selectedPlan.name} plan.`,
        status: "success",
        duration: 5000,
        isClosable: true,
      })
      setIsSubmitting(false)
      onClose()
    }, 2000)
  }

  const FormBackground = () => (
    <Box position="absolute" top={0} left={0} right={0} bottom={0} overflow="hidden" zIndex={-1}>
      <MotionBox
        position="absolute"
        top="-50%"
        right="-50%"
        width="100%"
        height="100%"
        borderRadius="full"
        bg="blue.50"
        filter="blur(50px)"
        opacity="0.4"
        animate={{
          scale: [1, 1.1, 1],
          rotate: [0, 10, 0],
        }}
        transition={{
          duration: 10,
          repeat: Number.POSITIVE_INFINITY,
          repeatType: "reverse",
        }}
      />
      <MotionBox
        position="absolute"
        bottom="-50%"
        left="-30%"
        width="80%"
        height="80%"
        borderRadius="full"
        bg="purple.50"
        filter="blur(60px)"
        opacity="0.4"
        animate={{
          scale: [1, 1.2, 1],
          rotate: [0, -10, 0],
        }}
        transition={{
          duration: 8,
          repeat: Number.POSITIVE_INFINITY,
          repeatType: "reverse",
          delay: 1,
        }}
      />
    </Box>
  )

  return (
    <Modal isOpen={isOpen} onClose={onClose} size="xl" motionPreset="slideInBottom">
      <ModalOverlay backdropFilter="blur(8px)" bg="rgba(0, 0, 0, 0.4)" />
      <ModalContent borderRadius="xl" overflow="hidden">
        <MotionBox
          as={ModalHeader}
          bgGradient="linear(to-r, blue.500, blue.600)"
          color="white"
          py={6}
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3 }}
        >
          <Flex align="center">
            <Icon as={Shield} mr={3} />
            Complete Your Purchase
          </Flex>
        </MotionBox>
        <ModalCloseButton color="white" />
        <ModalBody p={8} position="relative">
          <FormBackground />

          <VStack spacing={6} align="stretch" position="relative" zIndex={1}>
            <MotionBox
              bg="blue.50"
              p={4}
              borderRadius="lg"
              border="1px solid"
              borderColor="blue.100"
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.3, delay: 0.1 }}
            >
              <Flex justify="space-between" align="center">
                <VStack align="start" spacing={1}>
                  <Heading size="md" color="gray.800">
                    {selectedPlan?.name || "Selected Plan"}
                  </Heading>
                  <Text color="gray.600" fontSize="sm">
                    {selectedPlan?.description}
                  </Text>
                </VStack>
                <HStack spacing={2}>
                  <Text color="gray.500" fontSize="sm">
                    Price:
                  </Text>
                  <Text fontWeight="bold" color="blue.500" fontSize="xl">
                    ${selectedPlan?.price || 0}
                    <Text as="span" fontSize="sm" color="gray.500">
                      /mo
                    </Text>
                  </Text>
                </HStack>
              </Flex>
            </MotionBox>

            <MotionBox
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3, delay: 0.2 }}
            >
              <Tabs isFitted variant="soft-rounded" colorScheme="blue" onChange={(index) => setActiveTab(index)} mb={4}>
                <TabList>
                  {paymentMethods.map((method, index) => (
                    <Tab
                      key={method.id}
                      _selected={{
                        color: "blue.500",
                        bg: "blue.50",
                        boxShadow: "sm",
                        fontWeight: "semibold",
                      }}
                    >
                      <HStack spacing={2}>
                        <Image
                          src={method.icon || "/placeholder.svg"}
                          alt={method.name}
                          boxSize="24px"
                          objectFit="contain"
                        />
                        <Text>{method.name}</Text>
                      </HStack>
                    </Tab>
                  ))}
                </TabList>
                <TabPanels mt={6}>
                  {paymentMethods.map((method) => (
                    <TabPanel key={method.id} px={0}>
                      <form onSubmit={handleSubmit}>
                        <VStack spacing={5}>
                          <MotionFlex
                            w="full"
                            initial={{ opacity: 0, y: 10 }}
                            animate={{ opacity: 1, y: 0 }}
                            transition={{ delay: 0.1 }}
                          >
                            <FormControl isRequired>
                              <FormLabel fontWeight="medium">Card Number</FormLabel>
                              <InputGroup>
                                <InputLeftElement pointerEvents="none">
                                  <CreditCard size={18} color="gray" />
                                </InputLeftElement>
                                <Input
                                  type="text"
                                  placeholder="1234 5678 9012 3456"
                                  maxLength={19}
                                  value={cardNumber}
                                  onChange={(e) => setCardNumber(formatCardNumber(e.target.value))}
                                  borderRadius="lg"
                                  focusBorderColor="blue.400"
                                  _hover={{ borderColor: "blue.200" }}
                                />
                              </InputGroup>
                            </FormControl>
                          </MotionFlex>

                          <MotionFlex
                            w="full"
                            initial={{ opacity: 0, y: 10 }}
                            animate={{ opacity: 1, y: 0 }}
                            transition={{ delay: 0.2 }}
                          >
                            <FormControl isRequired>
                              <FormLabel fontWeight="medium">Cardholder Name</FormLabel>
                              <Input
                                type="text"
                                placeholder="John Doe"
                                value={cardName}
                                onChange={(e) => setCardName(e.target.value)}
                                borderRadius="lg"
                                focusBorderColor="blue.400"
                                _hover={{ borderColor: "blue.200" }}
                              />
                            </FormControl>
                          </MotionFlex>

                          <MotionFlex
                            gap={4}
                            w="full"
                            initial={{ opacity: 0, y: 10 }}
                            animate={{ opacity: 1, y: 0 }}
                            transition={{ delay: 0.3 }}
                          >
                            <FormControl isRequired flex="2">
                              <FormLabel fontWeight="medium">Expiry Date</FormLabel>
                              <HStack>
                                <Select
                                  placeholder="MM"
                                  value={expiryMonth}
                                  onChange={(e) => setExpiryMonth(e.target.value)}
                                  borderRadius="lg"
                                  focusBorderColor="blue.400"
                                  _hover={{ borderColor: "blue.200" }}
                                >
                                  {Array.from({ length: 12 }, (_, i) => {
                                    const month = i + 1
                                    return (
                                      <option key={month} value={month.toString().padStart(2, "0")}>
                                        {month.toString().padStart(2, "0")}
                                      </option>
                                    )
                                  })}
                                </Select>
                                <Select
                                  placeholder="YY"
                                  value={expiryYear}
                                  onChange={(e) => setExpiryYear(e.target.value)}
                                  borderRadius="lg"
                                  focusBorderColor="blue.400"
                                  _hover={{ borderColor: "blue.200" }}
                                >
                                  {Array.from({ length: 10 }, (_, i) => {
                                    const year = new Date().getFullYear() + i
                                    return (
                                      <option key={year} value={year.toString().slice(-2)}>
                                        {year.toString().slice(-2)}
                                      </option>
                                    )
                                  })}
                                </Select>
                              </HStack>
                            </FormControl>

                            <FormControl isRequired flex="1">
                              <FormLabel fontWeight="medium">CVV</FormLabel>
                              <Input
                                type="text"
                                maxLength={4}
                                placeholder="123"
                                value={cvv}
                                onChange={(e) => setCvv(e.target.value.replace(/\D/g, ""))}
                                borderRadius="lg"
                                focusBorderColor="blue.400"
                                _hover={{ borderColor: "blue.200" }}
                              />
                            </FormControl>
                          </MotionFlex>

                          <MotionButton
                            colorScheme="blue"
                            size="lg"
                            width="full"
                            mt={6}
                            type="submit"
                            isLoading={isSubmitting}
                            loadingText="Processing..."
                            borderRadius="xl"
                            bgGradient="linear(to-r, blue.400, blue.500, blue.600)"
                            _hover={{
                              bgGradient: "linear(to-r, blue.500, blue.600, blue.700)",
                              transform: "translateY(-2px)",
                              boxShadow: "xl",
                            }}
                            h="56px"
                            initial={{ opacity: 0, y: 10 }}
                            animate={{ opacity: 1, y: 0 }}
                            transition={{ delay: 0.4 }}
                            leftIcon={<Sparkles size={18} />}
                          >
                            Complete Purchase
                          </MotionButton>
                        </VStack>
                      </form>
                    </TabPanel>
                  ))}
                </TabPanels>
              </Tabs>
            </MotionBox>
          </VStack>
        </ModalBody>
      </ModalContent>
    </Modal>
  )
}

const Pricing = () => {
  const { isOpen, onOpen, onClose } = useDisclosure()
  const [selectedPlan, setSelectedPlan] = useState(null)
  const containerRef = useRef(null)
  const isInView = useInView(containerRef, { once: true, margin: "-100px" })
  const controls = useAnimation()

  useEffect(() => {
    if (isInView) {
      controls.start("visible")
    }
  }, [controls, isInView])

  const handleSelectPlan = (plan) => {
    setSelectedPlan(plan)
    onOpen()
  }

  const BackgroundElements = () => (
    <>
      <MotionBox
        position="absolute"
        top="5%"
        left="5%"
        width="40%"
        height="40%"
        borderRadius="full"
        bgGradient="linear(to-r, blue.400, blue.300)"
        filter="blur(120px)"
        opacity="0.1"
        animate={{
          scale: [1, 1.2, 1],
          x: [0, 50, 0],
          y: [0, 30, 0],
        }}
        transition={{
          duration: 15,
          repeat: Number.POSITIVE_INFINITY,
          repeatType: "reverse",
        }}
      />
      <MotionBox
        position="absolute"
        bottom="5%"
        right="5%"
        width="35%"
        height="35%"
        borderRadius="full"
        bgGradient="linear(to-r, purple.400, blue.400)"
        filter="blur(120px)"
        opacity="0.1"
        animate={{
          scale: [1, 1.3, 1],
          x: [0, -50, 0],
          y: [0, -30, 0],
        }}
        transition={{
          duration: 18,
          repeat: Number.POSITIVE_INFINITY,
          repeatType: "reverse",
          delay: 2,
        }}
      />
      <MotionBox
        position="absolute"
        top="30%"
        right="20%"
        width="25%"
        height="25%"
        borderRadius="full"
        bgGradient="linear(to-r, teal.300, blue.300)"
        filter="blur(100px)"
        opacity="0.05"
        animate={{
          scale: [1, 1.5, 1],
          rotate: [0, 180, 0],
        }}
        transition={{
          duration: 20,
          repeat: Number.POSITIVE_INFINITY,
          repeatType: "reverse",
          delay: 5,
        }}
      />
    </>
  )

  return (
    <Box as="section" py={20} bg="gray.900" color="white" position="relative" overflow="hidden" ref={containerRef}>
      <BackgroundElements />

      <Container maxW="container.xl" position="relative" zIndex={2}>
        <VStack spacing={8} mb={16}>
          <MotionHeading
            as="h2"
            fontSize={{ base: "4xl", md: "5xl" }}
            textAlign="center"
            bgGradient="linear(to-r, blue.400, blue.300, purple.400)"
            bgClip="text"
            initial="hidden"
            animate={controls}
            variants={{
              hidden: { opacity: 0, y: -50 },
              visible: { opacity: 1, y: 0, transition: { duration: 0.6 } },
            }}
            letterSpacing="tight"
            fontWeight="extrabold"
          >
            Choose Your Perfect Plan
          </MotionHeading>
          <MotionText
            fontSize={{ base: "lg", md: "xl" }}
            textAlign="center"
            maxW="2xl"
            color="gray.300"
            initial="hidden"
            animate={controls}
            variants={{
              hidden: { opacity: 0, y: 20 },
              visible: { opacity: 1, y: 0, transition: { duration: 0.6, delay: 0.2 } },
            }}
            lineHeight="tall"
          >
            Most calendars are designed for teams.
            <br />
            Slate is designed for freelancers who want a simple way to plan their schedule.
          </MotionText>

          <MotionBox
            py={2}
            px={4}
            bg="rgba(59, 130, 246, 0.1)"
            borderRadius="full"
            borderWidth="1px"
            borderColor="blue.500"
            initial="hidden"
            animate={controls}
            variants={{
              hidden: { opacity: 0, scale: 0.8 },
              visible: { opacity: 1, scale: 1, transition: { duration: 0.4, delay: 0.4 } },
            }}
          >
            <Text fontSize="sm" color="blue.300">
              Save up to 25% with annual billing
            </Text>
          </MotionBox>
        </VStack>

        <SimpleGrid columns={{ base: 1, md: 3 }} spacing={{ base: 10, md: 6, lg: 8 }} alignItems="stretch">
          {pricingPlans.map((plan, index) => (
            <PricingCard key={plan.id} plan={plan} onSelectPlan={handleSelectPlan} index={index} />
          ))}
        </SimpleGrid>
      </Container>

      <PaymentModal isOpen={isOpen} onClose={onClose} selectedPlan={selectedPlan} />
    </Box>
  )
}

export default Pricing

