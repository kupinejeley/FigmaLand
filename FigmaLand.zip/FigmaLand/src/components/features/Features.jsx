"use client"

import { useRef, useState, useEffect } from "react"
import { Box, Container, Heading, Text, Button, Image, Input, FormControl, useToast, Flex } from "@chakra-ui/react"
import { motion, useInView, useAnimation } from "framer-motion"

const MotionBox = motion(Box)
const MotionHeading = motion(Heading)
const MotionText = motion(Text)
const MotionButton = motion(Button)
const MotionImage = motion(Image)
const MotionFlex = motion(Flex)

const Footer = () => {
  const [email, setEmail] = useState("")
  const [isLaptopHovered, setIsLaptopHovered] = useState(false)
  const [mousePosition, setMousePosition] = useState({ x: 0, y: 0 })
  const toast = useToast()

  const preFooterRef = useRef(null)
  const footerRef = useRef(null)
  const macbookRef = useRef(null)
  const isPreFooterInView = useInView(preFooterRef, { once: true })
  const isFooterInView = useInView(footerRef, { once: true })
  const macbookControls = useAnimation()

  useEffect(() => {
    if (isPreFooterInView) {
      macbookControls.start({
        opacity: 1,
        y: 0,
        rotateX: 0,
        transition: {
          type: "spring",
          stiffness: 100,
          damping: 15,
          duration: 0.8,
        },
      })
    }
  }, [isPreFooterInView, macbookControls])

  const handleMouseMove = (e) => {
    if (!macbookRef.current) return

    const { left, top, width, height } = macbookRef.current.getBoundingClientRect()
    const x = (e.clientX - left) / width - 0.5
    const y = (e.clientY - top) / height - 0.5

    setMousePosition({ x, y })
  }

  const handleSubscribe = (e) => {
    e.preventDefault()
    if (!email) {
      toast({
        title: "Error",
        description: "Please enter your email address",
        status: "error",
        duration: 3000,
        isClosable: true,
      })
      return
    }

    toast({
      title: "Success!",
      description: "Thank you for subscribing to our newsletter!",
      status: "success",
      duration: 3000,
      isClosable: true,
    })
    setEmail("")
  }

  return (
    <>
      <Box as="section" py={20} bg="white" ref={preFooterRef} position="relative" overflow="hidden">
        <Container maxW="container.xl">
          <Flex direction={{ base: "column", lg: "row" }} align="center" justify="space-between" gap={10}>
            <MotionFlex
              flex="1"
              direction="column"
              align={{ base: "center", lg: "flex-start" }}
              initial={{ opacity: 0, x: -50 }}
              animate={isPreFooterInView ? { opacity: 1, x: 0 } : {}}
              transition={{ duration: 0.6 }}
            >
              <MotionHeading as="h2" fontSize={{ base: "3xl", md: "4xl", lg: "5xl" }} fontWeight="bold" mb={4}>
                Fastest way to organize
              </MotionHeading>

              <MotionText fontSize="lg" color="gray.600" mb={8}>
                Most calendars are designed for teams.
                <br />
                Slate is designed for freelancers
              </MotionText>

              <MotionButton
                colorScheme="blue"
                size="lg"
                rounded="full"
                px={8}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                Try For Free
              </MotionButton>
            </MotionFlex>

            <MotionBox
              ref={macbookRef}
              flex="1"
              position="relative"
              onMouseMove={handleMouseMove}
              onMouseEnter={() => setIsLaptopHovered(true)}
              onMouseLeave={() => setIsLaptopHovered(false)}
              initial={{ opacity: 0, y: 50, rotateX: 10 }}
              animate={macbookControls}
              style={{ perspective: "1200px" }}
            >
              <MotionBox
                position="relative"
                animate={{
                  rotateY: isLaptopHovered ? -mousePosition.x * 10 : 0,
                  rotateX: isLaptopHovered ? mousePosition.y * 10 : 0,
                }}
                transition={{
                  type: "spring",
                  stiffness: 300,
                  damping: 20,
                }}
                transformStyle="preserve-3d"
              >
                <Image
                  src="src/assets/Images/Frame 18.png"
                  alt="MacBook Pro"
                  width="100%"
                  height="auto"
                  style={{ transform: "translateZ(0)" }}
                />

                <Box
                  position="absolute"
                  top={0}
                  left={0}
                  right={0}
                  bottom={0}
                  borderRadius="16px"
                  background="linear-gradient(135deg, rgba(255,255,255,0) 0%, rgba(255,255,255,0.1) 100%)"
                  opacity={isLaptopHovered ? 1 : 0}
                  transition="opacity 0.3s ease"
                  style={{ transform: "translateZ(3px)" }}
                />

                <Box
                  position="absolute"
                  bottom="-20px"
                  left="5%"
                  right="5%"
                  height="40px"
                  background="radial-gradient(ellipse at center, rgba(0,0,0,0.2) 0%, rgba(0,0,0,0) 70%)"
                  borderRadius="50%"
                  transform="translateZ(-10px) rotateX(70deg)"
                  filter="blur(10px)"
                  zIndex="-1"
                />
              </MotionBox>
            </MotionBox>
          </Flex>
        </Container>
      </Box>

      <Box as="section" py={20} bg="gray.50" ref={footerRef}>
        <Container maxW="container.xl">
          <Flex direction={{ base: "column", lg: "row" }} align="center" justify="space-between" gap={10}>
            <MotionBox
              flex="1"
              initial={{ opacity: 0, x: -50 }}
              animate={isFooterInView ? { opacity: 1, x: 0 } : {}}
              transition={{ duration: 0.8 }}
            >
              <MotionBox
                animate={{
                  y: [0, -10, 0],
                }}
                transition={{
                  duration: 4,
                  repeat: Number.POSITIVE_INFINITY,
                  ease: "easeInOut",
                }}
              >
                <Image
                  src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/undraw_newsletter_vovu-skKILCod45kepHLSxYGhzcGTinfGas.png"
                  alt="Newsletter illustration"
                  width="100%"
                  maxW="500px"
                  height="auto"
                />
              </MotionBox>
            </MotionBox>

            <MotionFlex
              flex="1"
              direction="column"
              align={{ base: "center", lg: "flex-start" }}
              spacing={6}
              initial={{ opacity: 0, x: 50 }}
              animate={isFooterInView ? { opacity: 1, x: 0 } : {}}
              transition={{ duration: 0.8 }}
            >
              <MotionText color="blue.500" fontWeight="500" mb={2}>
                At your fingertips
              </MotionText>

              <MotionHeading as="h2" fontSize={{ base: "3xl", md: "4xl" }} fontWeight="bold" mb={4}>
                Lightning fast
                <br />
                prototyping
              </MotionHeading>

              <MotionText fontSize="lg" color="gray.600" mb={6}>
                Subscribe to our Newsletter
                <br />
                Available exclusively on Figmaland
              </MotionText>

              <form onSubmit={handleSubscribe} style={{ width: "100%" }}>
                <FormControl>
                  <Flex gap={4} direction={{ base: "column", sm: "row" }}>
                    <Input
                      placeholder="Your Email"
                      size="lg"
                      bg="white"
                      border="1px solid"
                      borderColor="gray.200"
                      _hover={{
                        borderColor: "blue.400",
                        transform: "translateY(-2px)",
                      }}
                      _focus={{
                        borderColor: "blue.400",
                        boxShadow: "0 0 0 3px rgba(66, 153, 225, 0.3)",
                      }}
                      transition="all 0.3s ease"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                    />
                    <MotionButton
                      type="submit"
                      colorScheme="blue"
                      size="lg"
                      px={8}
                      whileHover={{ scale: 1.05 }}
                      whileTap={{ scale: 0.95 }}
                    >
                      Subscribe
                    </MotionButton>
                  </Flex>
                </FormControl>
              </form>
            </MotionFlex>
          </Flex>
        </Container>
      </Box>
    </>
  )
}

export default Footer

