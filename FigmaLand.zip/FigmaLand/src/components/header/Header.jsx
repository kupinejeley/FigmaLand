"use client"

import { useState, useEffect, useRef } from "react"
import {
  Box, Flex, Text, Button, Stack, IconButton, Collapse, 
  useColorModeValue, useDisclosure, Container, HStack, Link, useToast,
} from "@chakra-ui/react"
import { motion, useScroll, useTransform } from "framer-motion"
import { Menu, X, Twitter, Facebook, Linkedin, ChevronDown, Sparkles } from "lucide-react"

const MotionBox = motion(Box)
const MotionFlex = motion(Flex)
const MotionText = motion(Text)
const MotionButton = motion(Button)
const MotionLink = motion(Link)

export default function Header() {
  const { isOpen, onToggle } = useDisclosure()
  const [scrolled, setScrolled] = useState(false)
  const [activeLink, setActiveLink] = useState("Home")
  const headerRef = useRef(null)
  const toast = useToast()

  const { scrollY } = useScroll()
  const opacity = useTransform(scrollY, [0, 100], [1, 0.8])
  const y = useTransform(scrollY, [0, 100], [0, -10])
  const scale = useTransform(scrollY, [0, 100], [1, 0.95])
  const logoColor = useTransform(scrollY, [0, 100], ["rgba(255, 255, 255, 1)", "rgba(59, 130, 246, 1)"])

  useEffect(() => {
    const handleScroll = () => {
      const offset = window.scrollY
      setScrolled(offset > 50)
    }

    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  const letterVariants = {
    initial: { y: 0 },
    hover: (i) => ({
      y: [-5, 0, -5],
      transition: {
        duration: 0.6,
        repeat: Number.POSITIVE_INFINITY,
        repeatType: "loop",
        delay: i * 0.1,
      },
    }),
  }

  const handleNavigate = (section) => {
    setActiveLink(section)

    const elementMap = {
      Home: "header-section",
      Product: "partners-section",
      Pricing: "pricing-section",
      About: "features-section",
      Contact: "contact-section",
    }

    const targetId = elementMap[section]

    if (targetId) {
      if (section === "Home") {
        window.scrollTo({
          top: 0,
          behavior: "smooth",
        })
      } else {
        const targetElement = document.getElementById(targetId)
        if (targetElement) {
          const headerHeight = document.querySelector("header")?.offsetHeight || 80

          window.scrollTo({
            top: targetElement.offsetTop - headerHeight,
            behavior: "smooth",
          })
        }
      }
    }
  }

  const handleTryForFree = () => {
    handleNavigate("Pricing")

    toast({
      title: "Free Trial Activated!",
      description: "Check out our pricing options below",
      status: "success",
      duration: 3000,
      position: "top",
      isClosable: true,
    })
  }

  const handleSocialClick = (platform) => {
    const socialUrls = {
      Twitter: "https://twitter.com/figma",
      Facebook: "https://facebook.com/figmadesign",
      LinkedIn: "https://linkedin.com/company/figma",
    }
    if (socialUrls[platform]) {
      window.open(socialUrls[platform], "_blank")
    }

    toast({
      title: `${platform} Profile`,
      description: `Opening ${platform} in a new tab`,
      status: "info",
      duration: 2000,
      position: "top-right",
      isClosable: true,
    })
  }

  const headerBg = useColorModeValue(
    scrolled ? "rgba(255, 255, 255, 0.9)" : "transparent",
    scrolled ? "rgba(26, 32, 44, 0.9)" : "transparent",
  )
  const textColor = useColorModeValue(scrolled ? "gray.800" : "white", scrolled ? "white" : "white")
  const hoverBg = useColorModeValue("blue.50", "blue.900")

  const Particles = () => (
    <>
      {[...Array(20)].map((_, i) => (
        <MotionBox
          key={i}
          position="absolute"
          width={Math.random() * 6 + 2}
          height={Math.random() * 6 + 2}
          borderRadius="full"
          bg="white"
          opacity={0.3}
          initial={{
            x: Math.random() * 100 + "%",
            y: Math.random() * 100 + "%",
          }}
          animate={{
            x: [Math.random() * 100 + "%", Math.random() * 100 + "%", Math.random() * 100 + "%"],
            y: [Math.random() * 100 + "%", Math.random() * 100 + "%", Math.random() * 100 + "%"],
            opacity: [0.2, 0.5, 0.2],
          }}
          transition={{
            duration: Math.random() * 20 + 10,
            repeat: Number.POSITIVE_INFINITY,
            ease: "linear",
          }}
        />
      ))}
    </>
  )

  return (
    <Box position="relative" ref={headerRef} id="header-section" as="header">
      <Box
        position="absolute"
        top={0}
        left={0}
        right={0}
        bottom={0}
        bgImage="url('src/assets/Images/Rectangle 9.png')"
        bgSize="cover"
        bgPosition="center"
        bgRepeat="no-repeat"
        _after={{
          content: '""',
          position: "absolute",
          top: 0,
          left: 0,
          right: 0,
          bottom: 0,
          bg: "linear-gradient(to bottom, rgba(0,0,0,0.7) 0%, rgba(0,0,0,0.5) 100%)",
        }}
        zIndex={-2}
      />

      <Box position="absolute" top={0} left={0} right={0} bottom={0} overflow="hidden" zIndex={-1}>
        <Particles />
      </Box>

      <MotionBox
        position="fixed"
        top={0}
        left={0}
        right={0}
        zIndex={1000}
        bg={headerBg}
        backdropFilter={scrolled ? "blur(10px)" : "none"}
        boxShadow={scrolled ? "lg" : "none"}
        transition="all 0.3s ease-in-out"
        style={{ opacity }}
        as="nav"
      >
        <Container maxW="container.xl">
          <Flex
            color={textColor}
            minH={"70px"}
            py={{ base: 2 }}
            px={{ base: 4 }}
            align={"center"}
            justify="space-between"
          >
            <Flex ml={{ base: -2 }} display={{ base: "flex", md: "none" }}>
              <IconButton
                onClick={onToggle}
                icon={isOpen ? <X size={24} /> : <Menu size={24} />}
                variant={"ghost"}
                aria-label={"Toggle Navigation"}
                color={textColor}
                _hover={{
                  bg: hoverBg,
                  transform: "scale(1.1)",
                }}
              />
            </Flex>

            <HStack spacing={8} align="center" display={{ base: "none", md: "flex" }}>
              {[
                { name: "Home", path: "home" },
                { name: "Product", path: "partners" },
                { name: "Pricing", path: "pricing" },
                { name: "About", path: "features" },
                { name: "Contact", path: "contact" },
              ].map((link) => (
                <MotionBox
                  key={link.name}
                  whileHover={{ scale: 1.1, y: -2 }}
                  whileTap={{ scale: 0.95 }}
                  position="relative"
                >
                  <Button
                    variant="ghost"
                    color={activeLink === link.name ? "blue.400" : textColor}
                    onClick={() => handleNavigate(link.name)}
                    _hover={{ bg: "transparent" }}
                    position="relative"
                    fontWeight="medium"
                    px={3}
                  >
                    {link.name}
                    {activeLink === link.name && (
                      <MotionBox
                        position="absolute"
                        bottom="-2px"
                        left={0}
                        right={0}
                        height="2px"
                        bg="blue.400"
                        layoutId="activeNavIndicator"
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        exit={{ opacity: 0 }}
                      />
                    )}
                  </Button>
                </MotionBox>
              ))}
            </HStack>

            <MotionFlex
              flex={{ base: 1, md: "auto" }}
              justify={{ base: "center", md: "center" }}
              align="center"
              whileHover="hover"
              cursor="pointer"
              onClick={() => handleNavigate("Home")}
            >
              <HStack spacing={1}>
                <MotionText
                  fontWeight="bold"
                  fontSize="xl"
                  color={scrolled ? "gray.800" : "white"}
                  style={{ color: logoColor }}
                  letterSpacing="wider"
                >
                  {"FIGMA".split("").map((letter, i) => (
                    <MotionText
                      as="span"
                      key={`figma-${i}`}
                      display="inline-block"
                      custom={i}
                      variants={letterVariants}
                    >
                      {letter}
                    </MotionText>
                  ))}
                </MotionText>

                <MotionBox
                  bg="blue.400"
                  w="20px"
                  h="20px"
                  borderRadius="sm"
                  mx={1}
                  whileHover={{
                    rotate: [0, 180, 360],
                    transition: { duration: 1.5, repeat: Number.POSITIVE_INFINITY },
                  }}
                />

                <MotionText
                  fontWeight="bold"
                  fontSize="xl"
                  color={scrolled ? "gray.800" : "white"}
                  style={{ color: logoColor }}
                  letterSpacing="wider"
                >
                  {"LAND".split("").map((letter, i) => (
                    <MotionText
                      as="span"
                      key={`land-${i}`}
                      display="inline-block"
                      custom={i + 5}
                      variants={letterVariants}
                    >
                      {letter}
                    </MotionText>
                  ))}
                </MotionText>
              </HStack>
            </MotionFlex>

            <Stack direction={"row"} spacing={6} display={{ base: "none", md: "flex" }} align="center">
              {[
                { icon: Twitter, platform: "Twitter", color: "#1DA1F2" },
                { icon: Facebook, platform: "Facebook", color: "#4267B2" },
                { icon: Linkedin, platform: "LinkedIn", color: "#0077B5" },
              ].map((social, index) => (
                <MotionBox
                  key={index}
                  whileHover={{
                    scale: 1.2,
                    rotate: 5,
                    y: -2,
                  }}
                  whileTap={{ scale: 0.9 }}
                >
                  <IconButton
                    size="md"
                    icon={<social.icon size={20} />}
                    aria-label={`${social.platform} profile`}
                    variant="ghost"
                    color={textColor}
                    _hover={{
                      bg: "whiteAlpha.200",
                      color: social.color,
                    }}
                    transition="all 0.3s"
                    onClick={() => handleSocialClick(social.platform)}
                  />
                </MotionBox>
              ))}
            </Stack>
          </Flex>

          <Collapse in={isOpen} animateOpacity>
            <Stack
              bg={useColorModeValue("white", "gray.800")}
              p={4}
              display={{ md: "none" }}
              spacing={4}
              borderRadius="md"
              boxShadow="xl"
              mt={2}
            >
              {[
                { name: "Home", path: "home" },
                { name: "Product", path: "partners" },
                { name: "Pricing", path: "pricing" },
                { name: "About", path: "features" },
                { name: "Contact", path: "contact" },
              ].map((link) => (
                <MotionBox
                  key={link.name}
                  whileHover={{ x: 5, backgroundColor: "rgba(66, 153, 225, 0.1)" }}
                  whileTap={{ scale: 0.95 }}
                  borderRadius="md"
                >
                  <Text
                    py={2}
                    px={3}
                    cursor="pointer"
                    fontWeight={activeLink === link.name ? "bold" : "normal"}
                    color={activeLink === link.name ? "blue.500" : "inherit"}
                    onClick={() => {
                      handleNavigate(link.name)
                      onToggle() 
                    }}
                  >
                    {link.name}
                  </Text>
                </MotionBox>
              ))}

              <HStack spacing={4} pt={2} justifyContent="center">
                {[
                  { icon: Twitter, platform: "Twitter", color: "#1DA1F2" },
                  { icon: Facebook, platform: "Facebook", color: "#4267B2" },
                  { icon: Linkedin, platform: "LinkedIn", color: "#0077B5" },
                ].map((social, index) => (
                  <MotionBox key={index} whileHover={{ scale: 1.2 }} whileTap={{ scale: 0.9 }}>
                    <IconButton
                      size="sm"
                      icon={<social.icon size={16} />}
                      aria-label={`${social.platform} profile`}
                      colorScheme="blue"
                      variant="ghost"
                      onClick={() => handleSocialClick(social.platform)}
                    />
                  </MotionBox>
                ))}
              </HStack>
            </Stack>
          </Collapse>
        </Container>
      </MotionBox>

      <Container maxW="container.xl" pt={{ base: 32, md: 40 }} pb={{ base: 20, md: 32 }}>
        <MotionFlex
          direction="column"
          align="center"
          justify="center"
          textAlign="center"
          initial="initial"
          animate="animate"
          style={{ y, scale }}
        >
          <MotionText
            as="h1"
            fontSize={{ base: "4xl", md: "6xl" }}
            fontWeight="bold"
            color="white"
            lineHeight="shorter"
            initial={{ opacity: 0, y: 50 }}
            animate={{
              opacity: 1,
              y: 0,
              transition: {
                duration: 0.8,
                ease: "easeOut",
              },
            }}
            textShadow="0 0 20px rgba(0,0,0,0.3)"
          >
            The best products
            <br />
            start with Figma
          </MotionText>

          <MotionText
            fontSize={{ base: "xl", md: "2xl" }}
            color="gray.300"
            initial={{ opacity: 0, y: 30 }}
            animate={{
              opacity: 1,
              y: 0,
              transition: {
                duration: 0.8,
                delay: 0.3,
                ease: "easeOut",
              },
            }}
            maxW="2xl"
            mt={6}
          >
            Most calendars are designed for teams. Slate is designed for freelancers
          </MotionText>

          <MotionBox
            initial={{ opacity: 0, y: 30 }}
            animate={{
              opacity: 1,
              y: 0,
              transition: {
                duration: 0.8,
                delay: 0.6,
                ease: "easeOut",
              },
            }}
            mt={10}
          >
            <MotionButton
              colorScheme="blue"
              size="lg"
              px={8}
              py={6}
              fontSize="lg"
              fontWeight="bold"
              rightIcon={<ChevronDown size={16} />}
              leftIcon={<Sparkles size={16} />}
              whileHover={{
                scale: 1.05,
                boxShadow: "0 0 20px rgba(66, 153, 225, 0.6)",
              }}
              whileTap={{ scale: 0.95 }}
              onClick={handleTryForFree}
              position="relative"
              overflow="hidden"
              _before={{
                content: '""',
                position: "absolute",
                top: 0,
                left: 0,
                width: "100%",
                height: "100%",
                background: "linear-gradient(110deg, transparent 25%, rgba(255,255,255,0.2) 50%, transparent 75%)",
                zIndex: 1,
              }}
              _hover={{
                _before: {
                  transform: "translateX(100%)",
                  transition: "transform 0.8s",
                },
              }}
            >
              Try For Free
            </MotionButton>
          </MotionBox>

          <MotionBox
            position="absolute"
            bottom="100px"
            left="50%"
            transform="translateX(-50%)"
            initial={{ opacity: 0 }}
            animate={{
              opacity: 1,
              y: [0, 10, 0],
              transition: {
                opacity: { delay: 1.5, duration: 1 },
                y: { repeat: Number.POSITIVE_INFINITY, duration: 1.5 },
              },
            }}
          >
          </MotionBox>
        </MotionFlex>
      </Container>

      <MotionBox
        position="absolute"
        bottom="-1px"
        left={0}
        right={0}
        height={{ base: "40px", md: "80px" }}
        overflow="hidden"
        zIndex={1}
        initial={{ opacity: 0 }}
        animate={{
          opacity: 1,
          transition: {
            delay: 1,
            duration: 0.5,
          },
        }}
      >
        <svg
          viewBox="0 0 1440 120"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
          preserveAspectRatio="none"
          style={{ width: "100%", height: "100%" }}
        >
          <motion.path
            d="M0 120V0C240 60 480 90 720 90C960 90 1200 60 1440 0V120H0Z"
            fill={useColorModeValue("white", "gray.900")}
            initial={{ y: 50 }}
            animate={{
              y: 0,
              transition: {
                duration: 1,
                ease: "easeOut",
              },
            }}
          />
        </svg>
      </MotionBox>
    </Box>
  )
}

  